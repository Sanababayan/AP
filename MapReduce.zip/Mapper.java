//package org.example;

import java.util.HashMap;

public class Mapper extends Thread {
    
    private final String string;
    HashMap<String, Integer> words;
    public Mapper(String input) {
        string = input;
        words = new HashMap<>();
    }
    
    @Override
    public void run () {
        String[] separatedWords = string.split("\\s+");
        for (String separatedWord : separatedWords) {
            if (separatedWord.equals("")) continue;
            words.put(separatedWord, words.getOrDefault(separatedWord, 0) + 1) ;
        }
    }
    
    public HashMap<String, Integer> getWordsFrequency() {
        return words;
    }
}