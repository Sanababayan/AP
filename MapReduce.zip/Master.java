//package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;

public class Master {
    private final String string;
    public Master(String input) throws InterruptedException {
        string = input;
        if (input == null) throw new InterruptedException();
    }
    
    public HashMap<String, Integer> getWordsFrequency() throws InterruptedException {
        HashMap<String, Integer> result = new HashMap<>();
        
        ArrayList<String> strings = new ArrayList<>(Arrays.asList("", "", "", ""));
        String[] lines = string.split("\\n+");
        for (int i = 0; i < lines.length; i++) {
            if (i > 3) strings.set(i % 4, strings.get(i % 4).concat(" "));
            strings.set(i % 4, strings.get(i % 4).concat(lines[i]));
        }
        
        Mapper[] mappers = new Mapper[4];
        for (int i = 0; i < mappers.length; i++) {
            mappers[i] = new Mapper(strings.get(i));
            mappers[i].start();
        }
    
        LinkedBlockingQueue<Reducer.WordCountPair>[] pairLists = new LinkedBlockingQueue[4];
        for (int i = 0; i < pairLists.length; i++) {
            pairLists[i] = new LinkedBlockingQueue<>();
        }
    
        for (Mapper mapper : mappers) {
            mapper.join();
            for (String s : mapper.getWordsFrequency().keySet()) {
                pairLists[s.hashCode() % 4].add(new Reducer.WordCountPair(s, mapper.getWordsFrequency().get(s)));
            }
        }
        
        Reducer[] reducers = new Reducer[4];
        for (int i = 0; i < reducers.length; i++) {
            reducers[i] = new Reducer(pairLists[i]);
            reducers[i].start();
        }
    
        for (Reducer reducer : reducers) {
            reducer.join();
            for (String s : reducer.getWordsFrequency().keySet()) {
                result.put(s, result.getOrDefault(s, 0) + reducer.getWordsFrequency().get(s));
            }
        }
        return result;
    }
}
