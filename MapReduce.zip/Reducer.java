//package org.example;

import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class Reducer extends Thread {
    private final LinkedBlockingQueue<WordCountPair> inputWords;
    private final HashMap<String, Integer> words;
    public static class WordCountPair {
        private final String word;
        private final Integer count;
        
        public WordCountPair(String word, Integer count) {
            this.word = word;
            this.count = count;
        }
        
        public String getWord() {
            return word;
        }
        
        public Integer getCount() {
            return count;
        }
    }
    
    public Reducer(LinkedBlockingQueue<WordCountPair> input){
        inputWords = input;
        words = new HashMap<>();
    }
    
    @Override
    public void run () {
        while (inputWords.size() > 0) {
            WordCountPair wordCountPair = inputWords.poll();
            words.put(wordCountPair.word, words.getOrDefault(wordCountPair.word, 0) + wordCountPair.count);
        }
    }
    
    public HashMap<String, Integer> getWordsFrequency() {
        return words;
    }
}