package Model;

import java.util.ArrayList;

public class User {
    private String name;
    private String id;
    private String password;
    private ArrayList<Chat> chats;
    public static ArrayList<Chat> currentChats = new ArrayList<>();
    public User (String id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        chats = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public ArrayList<Chat> getChats() {
        return chats;
    }

    public void addChat (Chat chat) {
        this.chats.add(chat);
    }

    public void addGroup (Group group) {
        this.chats.add(group);
    }

    public void addChannel (Channel channel) {
        this.chats.add(channel);
    }

    public void addPrivateChat (PrivateChat privateChat) { this.chats.add(privateChat); }
    public Group getGroupById (String id) {
        for (int i = 0; i < this.chats.size(); i++)
            if (this.chats.get(i).getId().equals(id) && this.chats.get(i) instanceof Group)
                return (Group) this.chats.get(i);
        return null;
    }
    public Channel getChannelById (String id) {
        for (int i = 0; i < this.chats.size(); i++)
            if(this.chats.get(i).getId().equals(id) && this.chats.get(i) instanceof Channel)
                return (Channel) this.chats.get(i);
        return null;
    }
    public PrivateChat getPrivateChatById (String id) {
        for (int i = 0; i < this.chats.size(); i++) {
            if(this.chats.get(i).getId().equals(id) && this.chats.get(i) instanceof PrivateChat)
                return (PrivateChat) this.chats.get(i);
        }
        return null;
    }
}
