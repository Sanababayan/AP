package Model;

import java.util.ArrayList;

public class Chat {
    private ArrayList<User> members;
    private ArrayList<Message> messages;
    private User owner;
    private String id;
    private String name;

    public Chat (User admin, String id, String name) {
        this.owner = admin;
        this.id = id;
        this.name = name;
        this.messages = new ArrayList<>();
        this.members = new ArrayList<>();
    }

    public void addMember (User user) {
        members.add(user);
    }

    public void addMessage (Message message) {
        messages.add(message);
    }

    public User getOwner () {
        return this.owner;
    }

    public String getId () {
        return this.id;
    }

    public String getName () {
        return this.name;
    }

    public ArrayList<Message> getMessages () {
        return this.messages;
    }

    public ArrayList<User> getMembers() {
        return this.members;
    }
}
