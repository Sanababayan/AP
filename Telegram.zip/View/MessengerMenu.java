package View;
import Model.*;
import java.util.*;
import java.util.regex.Matcher;

public class MessengerMenu {
    private Chat chat;
    private User currentUser;
    public void run(Scanner scanner) {
        Matcher matcher;
        currentUser = Messenger.getCurrentUser();
        String input;
        while (true) {
            input = scanner.nextLine();
            matcher = Commands.getMatcher(input, Commands.showAllChannels);
            if (matcher.matches())
                System.out.println(showAllChannels());
            else {
                matcher = Commands.getMatcher(input, Commands.showMyChats);
                if (matcher.matches())
                    System.out.println(showChats());
                else {
                    matcher = Commands.getMatcher(input, Commands.enterChat);
                    if(matcher.matches()) {
                        String out = enterChat(matcher);
                        System.out.println(out);
                        if (out.equals("You have successfully entered the chat!")) {
                            ChatMenu chatMenu = new ChatMenu();
                            chatMenu.run(scanner, chat);
                        }
                    }
                    else {
                        matcher = Commands.getMatcher(input, Commands.createNewChannel);
                        if(matcher.matches())
                            System.out.println(createChannel(matcher));
                        else {
                            matcher = Commands.getMatcher(input, Commands.createNewGroup);
                            if(matcher.matches())
                                System.out.println(createGroup(matcher));
                            else {
                                matcher = Commands.getMatcher(input, Commands.startNewPrivateChat);
                                if (matcher.matches())
                                    System.out.println(createPrivateChat(matcher));
                                else {
                                    matcher = Commands.getMatcher(input, Commands.joinChannel);
                                    if(matcher.matches())
                                        System.out.println(joinChannel(matcher));
                                    else {
                                        matcher = Commands.getMatcher(input, Commands.logout);
                                        if(matcher.matches()) {
                                            System.out.println("Logged out");
                                            return;
                                        }
                                        else
                                            System.out.println("Invalid command!");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    private String showAllChannels() {
        StringBuilder output = new StringBuilder();
        output.append("All channels:");
        for (int i = 0; i < Messenger.getChannels().size(); i++)
            output.append("\n").append(i + 1).append(". ").append(Messenger.getChannels().get(i).getName()).append(", id: ").append(Messenger.getChannels().get(i).getId()).append(", members: ").append(Messenger.getChannels().get(i).getMembers().size());
        return output.toString();
    }
    private String showChats() {
        StringBuilder output = new StringBuilder();
        output.append("Chats:");
        String typeOfChat = "";
        for (int i = currentUser.getChats().size() - 1; i >= 0; i--) {
            if(currentUser.getChats().get(i) instanceof PrivateChat)
                typeOfChat = "private chat";
            else if(currentUser.getChats().get(i) instanceof Channel)
                typeOfChat = "channel";
            else
                typeOfChat = "group";
            output.append("\n").append(currentUser.getChats().size() - i).append(". ").append(currentUser.getChats().get(i).getName()).append(", id: ").append(currentUser.getChats().get(i).getId()).append(", ").append(typeOfChat);
        }
        return output.toString();
    }
    private String enterChat (Matcher matcher) {
        matcher.matches();
        if (matcher.group("type").equals("group") &&
                currentUser.getGroupById(matcher.group("id")) != null) {
            this.chat = currentUser.getGroupById(matcher.group("id"));
            return "You have successfully entered the chat!";
        }
        else if (matcher.group("type").equals("channel") &&
                currentUser.getChannelById(matcher.group("id")) != null) {
            this.chat = currentUser.getChannelById(matcher.group("id"));
            return "You have successfully entered the chat!";
        }
        else if (currentUser.getPrivateChatById(matcher.group("id")) != null) {
            this.chat = currentUser.getPrivateChatById(matcher.group("id"));
            return "You have successfully entered the chat!";
        }
        return "You have no " + matcher.group("type") + " with this id!";
    }
    private String createChannel(Matcher matcher) {
        String id = matcher.group("id");
        String name = matcher.group("name");
        if(! name.matches("[0-9a-zA-Z_]+")) return "Channel name's format is invalid!";
        if (Messenger.getChannelById(id) != null) return "A channel with this id already exists!";
        Channel channel = new Channel(currentUser, id, name);
        Messenger.addChannel(channel);
        currentUser.addChannel(channel);
        channel.addMember(currentUser);
        return ("Channel " + name + " has been created successfully!");
    }
    private String createGroup(Matcher matcher) {
        String id = matcher.group("id");
        String name = matcher.group("name");
        if(! name.matches("[0-9a-zA-Z_]+")) return "Group name's format is invalid!";
        if (Messenger.getGroupById(id) != null) return "A group with this id already exists!";
        StringBuilder output = new StringBuilder();
        output.append("Group ");
        output.append(name);
        output.append(" has been created successfully!");
        Group group = new Group(currentUser, id, name);
        Messenger.addGroup(group);
        currentUser.addGroup(group);
        group.addMember(currentUser);
        return output.toString();
    }
    private String createPrivateChat(Matcher matcher) {
        String id = matcher.group("id");
        if(currentUser.getPrivateChatById(id) != null)
            return "You already have a private chat with this user!";
        if(Messenger.getUserById(id) != null) {
            PrivateChat privateChat = new PrivateChat(currentUser, id, Messenger.getUserById(id).getName());
            privateChat.addMember(currentUser);
            currentUser.addPrivateChat(privateChat);
            if(!currentUser.equals(Messenger.getUserById(id))) {
                privateChat.addMember(Messenger.getUserById(id));
                PrivateChat privateChat1 = new PrivateChat(Messenger.getUserById(id), currentUser.getId(), currentUser.getName());
                Messenger.getUserById(id).addPrivateChat(privateChat1);
                privateChat1.addMember(currentUser);
                privateChat1.addMember(Messenger.getUserById(id));
            }
            return "Private chat with " + Messenger.getUserById(id).getName() + " has been started successfully!";
        }
        else
            return "No user with this id exists!";
    }
    private String joinChannel(Matcher matcher) {
        String channelId = matcher.group("channelId");
        if(Messenger.getChannelById(channelId) == null) {
            return "No channel with this id exists!";
        }
        else if(Messenger.getChannelById(channelId).getMembers().contains(currentUser))
            return "You're already a member of this channel!";
        else {
            Messenger.getChannelById(channelId).addMember(currentUser);
            currentUser.addChannel(Messenger.getChannelById(channelId));
            return "You have successfully joined the channel!";
        }
    }
}
