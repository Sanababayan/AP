package View;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    register("register i (?<id>\\S+) u (?<username>\\S+) p (?<password>.+)"),
    login("login i (?<id>\\S+) p (?<password>\\S+)"),
    showAllChannels("show all channels"),
    createNewChannel("create new channel i (?<id>\\S+) n (?<name>\\S+)"),
    joinChannel("join channel i (?<channelId>\\S+)"),
    showMyChats("show my chats"),
    createNewGroup("create new group i (?<id>\\S+) n (?<name>\\S+)"),
    startNewPrivateChat("start a new private chat with i (?<id>\\S+)"),
    logout("logout"),
    enterChat("enter (?<type>(private chat|group|channel)) i (?<id>[^ ]+)"),
    sendMessage("^send a message c (?<message>.*)$"),
    addMember("^add member i (?<id>\\S+)$"),
    showAllMessages("show all messages"),
    showAllMembers("show all members"),
    exit("exit"),
    back("back");
    private final String regex;

    Commands(String value) {
        this.regex = value;
    }

    public static Matcher getMatcher(String input, Commands commands) {
        Pattern pattern = Pattern.compile(commands.regex);
        return pattern.matcher(input);
    }
}