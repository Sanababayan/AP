package View;
import Model.*;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;

public class ChatMenu {
    private Chat chat;
    private User currentUser;
    static String input;

    public void run(Scanner scanner, Chat chat) {
        this.chat = chat;
        currentUser = Messenger.getCurrentUser();
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            matcher = Commands.getMatcher(input, Commands.showAllMessages);
            if (matcher.matches())
                System.out.println(showMessages());
            else {
                matcher = Commands.getMatcher(input, Commands.showAllMembers);
                if (matcher.matches())
                    System.out.println(showMembers());
                else {
                    matcher = Commands.getMatcher(input, Commands.addMember);
                    if (matcher.matches())
                        System.out.println(addMember(matcher));
                    else {
                        matcher = Commands.getMatcher(input, Commands.sendMessage);
                        if (matcher.matches())
                            System.out.println(sendMessage(matcher));
                        else {
                            matcher = Commands.getMatcher(input, Commands.back);
                            if (matcher.matches())
                                return;
                            else {
                                System.out.println("Invalid command!");
                            }
                        }
                    }
                }
            }
        }
    }

    private String showMessages() {
        StringBuilder output = new StringBuilder();
        output.append("Messages:");
        for (int i = 0; i < chat.getMessages().size(); i++) {
            output.append("\n");
            output.append(chat.getMessages().get(i).getOwner().getName());
            output.append("(");
            output.append(chat.getMessages().get(i).getOwner().getId());
            output.append("): \"");
            output.append(chat.getMessages().get(i).getContent());
            output.append(("\""));
        }
        return output.toString();
    }

    private String showMembers() {
        if (chat instanceof PrivateChat) {
            return "Invalid command!";
        } else {
            StringBuilder output = new StringBuilder();
            output.append("Members:");
            for (int i = 0; i < chat.getMembers().size(); i++) {
                output.append("\n");
                output.append("name: ");
                output.append(chat.getMembers().get(i).getName());
                output.append(", id: ");
                output.append(chat.getMembers().get(i).getId());
                if (chat.getMembers().get(i).equals(chat.getOwner()))
                    output.append(" *owner");
            }
            return output.toString();
        }
    }

    private String addMember(Matcher matcher) {
        String id = matcher.group("id");
        if (chat instanceof PrivateChat) {
            return "Invalid command!";
        } else {
            if (!chat.getOwner().equals(currentUser)) {
                return "You don't have access to add a member!";
            }
            User addingUser = Messenger.getUserById(id);
            if (addingUser == null) {
                return "No user with this id exists!";
            } else {
                if (chat.getMembers().contains(addingUser)) {
                    return "This user is already in the chat!";
                }
                else {
                    chat.addMember(addingUser);
                    if (chat instanceof Channel) {
                        addingUser.addChannel((Channel) chat);
                    } else {
                        addingUser.addGroup((Group) chat);
                        StringBuilder argument = new StringBuilder();
                        //argument.append("send a message c ");
                        argument.append(addingUser.getName());
                        argument.append(" has been added to the group!");
                        //this.sendMessage(Commands.getMatcher(argument.toString(), Commands.sendMessage));
                        chat.addMessage(new Message(currentUser, argument.toString()));
                        for (User user : chat.getMembers()) {
                            user.getChats().remove(chat);
                            user.getChats().add(chat);
                        }
                    }
                    return "User has been added successfully!";
                }
            }
        }
    }

    private String sendMessage(Matcher matcher) {
        String message = matcher.group("message");
        if (chat instanceof Channel && !chat.getOwner().equals(currentUser))
            return "You don't have access to send a message!";
        else {
            chat.addMessage(new Message(currentUser, message));
            if (chat instanceof PrivateChat) {
                currentUser.getChats().remove(chat);
                currentUser.getChats().add(chat);
                if (chat.getMembers().size() != 1) {
                    PrivateChat tempChat = Messenger.getUserById(chat.getId()).getPrivateChatById(currentUser.getId());
                    tempChat.addMessage(chat.getMessages().get(chat.getMessages().size() - 1));
                    Messenger.getUserById(chat.getId()).getChats().remove(tempChat);
                    Messenger.getUserById(chat.getId()).addPrivateChat(tempChat);
                }
            } else
                for (User user : chat.getMembers()) {
                    user.getChats().remove(chat);
                    user.getChats().add(chat);
                }
            return "Message has been sent successfully!";
        }
    }
}
