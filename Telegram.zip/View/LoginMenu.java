package View;
import Model.Messenger;
import Model.User;
import java.util.Scanner;
import java.util.regex.Matcher;

public class LoginMenu {
    static String input;
    public void run(Scanner scanner) {
        Matcher matcher;
        while(true) {
            input = scanner.nextLine();
            matcher = Commands.getMatcher(input, Commands.login);
            if(matcher.matches()) {
                String output = login(matcher);
                System.out.println(output);
                if(output.equals("User successfully logged in!")) {
                    MessengerMenu messengerMenu = new MessengerMenu();
                    messengerMenu.run(scanner);
                }
            }
            else {
                matcher = Commands.getMatcher(input, Commands.register);
                if(matcher.matches()) {
                    System.out.println(register(matcher));
                }
                else {
                    matcher = Commands.getMatcher(input, Commands.exit);
                    if(matcher.matches()) {
                        return;
                    }
                    else {
                        System.out.println("Invalid command!");
                    }
                }
            }
        }
    }
    private String login(Matcher matcher) {
        String id = matcher.group("id");
        String password = matcher.group("password");
        if(Messenger.getUserById(id) == null) {
            return "No user with this id exists!";//^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[*.!:;<>,?\/~_|^&\-=(){}\[\]+@#$%]).{8,32}$
        } else if (!Messenger.getUserById(id).getPassword().equals(password)) {
            return "Incorrect password!";
        }else {
            Messenger.setCurrentUser(Messenger.getUserById(id));
            return "User successfully logged in!";
        }
    }
    private String register(Matcher matcher) {
        String id = matcher.group("id");
        String userName = matcher.group("username");
        String password = matcher.group("password");
        if(! userName.matches("[a-zA-Z0-9_]+"))
            return "Username's format is invalid!";
        else if(! password.matches("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[\\[\\]{}*.!:;<>,?\\/~_|@#$%^&\\-+=()])(\\S+){8,32}"))
            return "Password is weak!";
        else {
            if(Messenger.getUserById(id) != null) {
                return "A user with this ID already exists!";
            }
            else {
                Messenger.addUser(new User(id, userName, password));
                return "User has been created successfully!";
            }
        }
    }
}
