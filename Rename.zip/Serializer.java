import java.lang.reflect.Field;
import java.util.Objects;

public class Serializer {
    public Object object;
    public String getSerializedString() throws IllegalAccessException {
        StringBuilder stringBuilder = new StringBuilder();
        for (Class<?> c = object.getClass(); c != null; c = c.getSuperclass()) {
        //Class c = object.getClass();
        Field[] fields = c.getDeclaredFields();
        for(int i = 0; i < fields.length; i++) {
            for (int j = i + 1; j < fields.length; j++) {
                boolean access = fields[i].isAccessible();
                fields[i].setAccessible(true);
                if(fields[i].getName().compareTo(fields[j].getName()) > 0) {
                    Field temp = fields[i];
                    fields[i] = fields[j];
                    fields[j]= temp;
                }
                fields[i].setAccessible(access);
            }
        }
        //stringBuilder.append("{\"");
        for (int i = 0 ; i < fields.length; i++) {
            boolean access = fields[i].isAccessible();
            fields[i].setAccessible(true);
            if (fields[i].getAnnotation(Rename.class) != null && fields[i].getAnnotation(Rename.class).name() != null && !Objects.equals(fields[i].getAnnotation(Rename.class).name(), "")) {
                if (i == fields.length - 1) {
                    stringBuilder.append(fields[i].getAnnotation(Rename.class).name()).append(":").append(fields[i].get(object));
                } else {
                    stringBuilder.append(fields[i].getAnnotation(Rename.class).name()).append(":").append(fields[i].get(object)).append(",");
                }
            } else {
            try {
                if (i == fields.length - 1) {
                    stringBuilder.append(fields[i].getName()).append(":").append(fields[i].get(object));
                } else {
                    stringBuilder.append(fields[i].getName()).append(":").append(fields[i].get(object)).append(",");
                }
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
            fields[i].setAccessible(access);
        }
        //stringBuilder.append("\"}");
        }
        return stringBuilder.toString();
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }
}