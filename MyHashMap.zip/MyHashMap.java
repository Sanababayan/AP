import java.util.ArrayList;
import java.util.Objects;

public class MyHashMap<K, V> {
    
    private final ArrayList<K> keys = (ArrayList<K>) new ArrayList<Objects>();
    private final ArrayList<V> values = (ArrayList<V>) new ArrayList<Objects>();
    
    public void put(K key, V value) {
        remove(key);
        keys.add(key);
        values.add(value);
    }
    
    public V get(K key) {
        if (keys.contains(key)) return values.get(keys.indexOf(key));
        return null;
    }
    
    public void remove(K key) {
        if (keys.contains(key)) {
            values.remove(keys.indexOf(key));
            keys.remove(key);
        }
    }
}