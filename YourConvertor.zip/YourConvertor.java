import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YourConvertor {
    public Object deserialize(String input, String className) {
        Class<?> cc = null;
        try {
            cc = Class.forName(className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        Object object = null;
        try {
            object = cc.newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        Pattern pattern = Pattern.compile("\"(?<key>[^\"]*)\":((\"(?<stringValue>[^\"]*\"))|(?<floatValue>[-+]?([0-9]+(\\.[0-9]*)|\\.[0-9]+))|(?<intValue>[-+]?[0-9]+)|(?<classValue>\\{[^\\}]*})|(?<arrayListValue>\\[[0-9,]*]))");
        try {
            for (Class<?> c = Class.forName(className); c != null; c = c.getSuperclass()) {
                if (c.equals(Object.class)) break;
                Field[] declaredFields = c.getDeclaredFields();
                for (Field field : declaredFields) {
                    Matcher matcher = pattern.matcher(input);
                    while (matcher.find()) {
                        boolean access = field.isAccessible();
                        field.setAccessible(true);
                        if (field.getName().equals(matcher.group("key"))) {
                            if (field.getType() == Integer.TYPE) {
                                System.out.println("int");
                                field.set(object, Integer.parseInt(matcher.group("intValue")));
                                break;
                            } else if (field.getType() == Character.TYPE) {
                                field.set(object, matcher.group("stringValue").charAt(0));
                            } else if (field.getType() == String.class) {
                                String s1 = field.getName().substring(0, 1).toUpperCase();
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("set").append(s1).append(field.getName().substring(1));
                                Method[] methods = c.getMethods();
                                int flag = 0;
                                for (Method method : methods) {
                                    if (method.getName().equals(stringBuilder.toString())) {
                                        flag = 1;
                                        method.invoke(object, matcher.group("stringValue").replace("\"", ""));
                                    }
                                }
                                if (flag == 0)
                                    field.set(object, matcher.group("stringValue").replace("\"", ""));
                                break;
                            } else if (field.getType() == Float.TYPE) {
                                field.set(object, Float.parseFloat(matcher.group("floatValue")));
                                break;
                            } else if (field.getType() == ArrayList.class) {
                                String sampleArrayList = matcher.group("arrayListValue");
                                sampleArrayList = sampleArrayList.substring(1, sampleArrayList.length() - 1);
                                String[] result = sampleArrayList.split(",", 0);
                                ArrayList<Integer> arrayList = new ArrayList<>();
                                for (String sub_string : result) {
                                    arrayList.add(Integer.parseInt(sub_string));
                                }
                                field.set(object, arrayList);
                                break;
                            } else if (matcher.group("classValue") != null) {
                                field.set(object, deserialize(matcher.group("classValue"), field.getType().getName()));
                                break;
                            }
                        }
                        field.setAccessible(access);
                    }
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
        return object;
    }

    public String serialize(Object input) {
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<Field> fields = new ArrayList<>();
        for (Class<?> c = input.getClass(); c != null; c = c.getSuperclass()) {
            if (c.equals(Object.class)) break;
            for (int j = 0; j < c.getDeclaredFields().length; j++) {
                fields.add(c.getDeclaredFields()[j]);
            }
        }
        for (int i = 0; i < fields.size(); i++) {
            for (int j = i + 1; j < fields.size(); j++) {
                boolean access = fields.get(i).isAccessible();
                fields.get(i).setAccessible(true);
                if (fields.get(i).getName().compareTo(fields.get(j).getName()) > 0) {
                    Field temp = fields.get(i);
                    fields.set(i, fields.get(j));
                    fields.set(j, temp);
                }
                fields.get(i).setAccessible(access);
            }
        }
        stringBuilder.append("{");
        for (int i = 0; i < fields.size(); i++) {
            boolean access = fields.get(i).isAccessible();
            fields.get(i).setAccessible(true);
            try {
                if (i == fields.size() - 1) {
                    if (fields.get(i).getType() == String.class) {
                        StringBuilder methodName = new StringBuilder();
                        String s1 = fields.get(i).getName().substring(0, 1).toUpperCase();
                        methodName.append("get").append(s1).append(fields.get(i).getName().substring(1));
                        Method[] methods = input.getClass().getMethods();
                        int flag = 0;
                        for (Method method : methods) {
                            if (method.getName().equals(methodName.toString())) {
                                flag = 1;
                                stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(method.invoke(input)).append("\"");
                            }
                        }
                        if (flag == 0)
                            stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(fields.get(i).get(input)).append("\"");
                    } else if (fields.get(i).getType() == Boolean.TYPE || fields.get(i).getType() == Integer.TYPE || fields.get(i).getType() == Long.TYPE || fields.get(i).getType() == Double.TYPE || fields.get(i).getType() == Float.TYPE)
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":").append(fields.get(i).get(input));
                    else if (fields.get(i).getType() == Character.TYPE)
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(fields.get(i).get(input)).append("\"");
                    else if (fields.get(i).getType() == ArrayList.class) {
                        ArrayList array = (ArrayList) fields.get(i).get(input);
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":[");
                        for (int arrayElement = 0; arrayElement < array.size(); arrayElement++) {
                            if (arrayElement < arrayElement - 1)
                                stringBuilder.append(array.get(arrayElement)).append(",");
                            else stringBuilder.append(array.get(arrayElement));
                        }
                        stringBuilder.append("]");
                    } else {
                        //System.out.println(fields[i].getName() + "<-if");
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":").append(this.serialize(fields.get(i).get(input)));
                    }
                } else {
                    if (fields.get(i).getType() == String.class) {
                        StringBuilder methodName = new StringBuilder();
                        String s1 = fields.get(i).getName().substring(0, 1).toUpperCase();
                        methodName.append("get").append(s1).append(fields.get(i).getName().substring(1));
                        Method[] methods = input.getClass().getMethods();
                        int flag = 0;
                        for (Method method : methods) {
                            if (method.getName().equals(methodName.toString())) {
                                flag = 1;
                                stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(method.invoke(input)).append("\",");
                            }
                        }
                        if (flag == 0)
                            stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(fields.get(i).get(input)).append("\",");
                    } else if (fields.get(i).getType() == Boolean.TYPE || fields.get(i).getType() == Integer.TYPE || fields.get(i).getType() == Long.TYPE || fields.get(i).getType() == Double.TYPE || fields.get(i).getType() == Float.TYPE)
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":").append(fields.get(i).get(input)).append(",");
                    else if (fields.get(i).getType() == Character.TYPE)
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":\"").append(fields.get(i).get(input)).append("\",");
                    else if (fields.get(i).getType().equals(ArrayList.class)) {
                        ArrayList array = (ArrayList) fields.get(i).get(input);
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":[");
                        for (int arrayElement = 0; arrayElement < array.size(); arrayElement++) {
                            if (arrayElement == array.size() - 1) stringBuilder.append(array.get(arrayElement));
                            else stringBuilder.append(array.get(arrayElement)).append(",");
                        }
                        stringBuilder.append("],");
                    } else {
                        //System.out.println(fields[i].getName() + "<-else");
                        stringBuilder.append("\"").append(fields.get(i).getName()).append("\":").append(this.serialize(fields.get(i).get(input)));
                    }
                }
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
            fields.get(i).setAccessible(access);
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}