package Controller;

import java.util.regex.Pattern;

public enum Terms {
    VALID_USERNAME ("(?=.*[A-Za-z])[A-Za-z0-9_]+"),
    DISCOUNT_VALIDATION("[a-zA-Z0-9]+"),
    CATEGORY_VALIDATION("(starter|entree|dessert)"),
    TYPE_VALIDATION ("[a-z-]+"),
    VALID_PASSWORD ("[A-Za-z0-9_]+"),
    STRONG_PASSWORD ("(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])\\S{5,}"),
    CUSTOMER_MENU ("\\s*customer\\s+menu\\s*"),
    SNAPPFOOD_ADMIN_MENU("\\s*Snappfood\\s+admin\\s+menu\\s*"),
    RESTAURANT_ADMIN_MENU("\\s*restaurant\\s+admin\\s+menu\\s*");
    private final String regex;
    private Terms(String regex) {
        this.regex = regex;
    }
    public static boolean check (String string, Terms term) {
        return Pattern.compile(term.regex).matcher(string).matches();
    }
}
