package Controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    LOGIN_REGISTER ("\\s*register\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*"),
    LOGIN_LOGIN ("\\s*login\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*"),
    LOGIN_REMOVE_ACCOUNT ("\\s*remove\\s+account\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*"),
    LOGIN_EXIT ("\\s*exit\\s*"),
    LOGIN_CHANGE_PASSWORD("\\s*change\\s+password\\s+(?<username>\\S+)\\s+(?<oldPassword>\\S+)\\s+(?<newPassword>\\S+)\\s*"),
    SHOW_CURRENT_MENU("\\s*show\\s+current\\s+menu\\s*"),
    MAIN_ENTER("\\s*enter\\s+(?<menuName>.+)\\s*"),
    LOGOUT("\\s*logout\\s*"),
    SNAPPFOOD_ADMIN_ADD_RESTAURANT("\\s*add\\s+restaurant\\s+(?<name>\\S+)\\s+(?<password>\\S+)\\s+(?<type>.+)\\s*"),
    SHOW_RESTAURANT("\\s*show\\s+restaurant(\\s+-t\\s+(?<type>\\S+))?\\s*"),
    REMOVE_RESTAURANT("\\s*remove\\s+restaurant\\s+(?<name>.+)\\s*"),
    SET_DISCOUNT("\\s*set\\s+discount\\s+(?<username>\\S+)\\s+(?<amount>-?[0-9]+)\\s+(?<code>.+)\\s*"),
    SHOW_DISCOUNT("\\s*show\\s+discounts\\s*"),
    RESTAURANT_CHARGE_ACCOUNT("\\s*charge\\s+account\\s+(?<amount>-?[0-9]+)\\s*"),
    SHOW_BALANCE("\\s*show\\s+balance\\s*"),
    ADD_FOOD("\\s*add\\s+food\\s+(?<name>\\S+)\\s+(?<category>\\S+)\\s+(?<price>-?[0-9]+)\\s+(?<cost>-?[0-9]+)\\s*"),
    REMOVE_FOOD("\\s*remove\\s+food\\s+(?<name>.+)\\s*"),
    SHOW_RESTAURANT_MENU("\\s*show\\s+menu\\s+(?<restaurantName>\\S+)(\\s+-c\\s+(?<category>.+))?"),
    ADD_TO_CART("\\s*add\\s+to\\s+cart\\s+(?<restaurantName>\\S+)\\s+(?<foodName>\\S+)(\\s+-n\\s+(?<number>-?[0-9]+))?\\s*"),//[a-z\-]
    REMOVE_FROM_CART("\\s*remove\\s+from\\s+cart\\s+(?<restaurantName>\\S+)\\s+(?<foodName>\\S+)(\\s+-n\\s+(?<number>-?[0-9]+))?\\s*"),
    SHOW_CART("\\s*show\\s+cart\\s*"),
    PURCHASE_CART("\\s*purchase\\s+cart(\\s+-d\\s+(?<discountCode>.+))?");
    final String regex;
    private Commands(String regex) {
        this.regex = regex;
    }
    public static boolean matches (String string, Commands command) {
        return Pattern.matches(command.regex, string);
    }
    public static Matcher getMatcher (String string, Commands command) {
        Matcher matcher =Pattern.compile(command.regex).matcher(string);
        matcher.matches();
        return matcher;
    }
}