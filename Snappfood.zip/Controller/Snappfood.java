package Controller;
import Model.*;
import View.CustomerMenu;
import View.LoginMenu;

import java.util.ArrayList;
import java.util.regex.Matcher;

public class Snappfood {
    public static User user;
    private static SnappfoodAdmin admin;
    private static ArrayList<RestaurantAdmin> restaurantAdmins = new ArrayList<>();
    private static ArrayList<Foods> allFoods = new ArrayList<>();
    private static final ArrayList<User> users = new ArrayList<>();

    public static boolean setAdmin(SnappfoodAdmin admin) {
        if (Snappfood.admin != null) return false;
        Snappfood.admin = admin;
        return true;
    }

    public static SnappfoodAdmin getAdmin() {
        return admin;
    }
    public static void addUser (User user) {
        users.add(user);
    }

    public static ArrayList<RestaurantAdmin> getRestaurantAdmins() {
        return restaurantAdmins;
    }

    public static ArrayList<Foods> getAllFoods() {
        return allFoods;
    }

    public static void addAllFoods(Foods food) {
        allFoods.add(food);
    }
    public static Foods foodName (String foodName) {
        for (Foods food : allFoods) {
            if (food.getName().equals(foodName)) return food;
        }
        return null;
    }
    public static void addRestaurantAdmin (RestaurantAdmin admin) {
        restaurantAdmins.add(admin);
    }
    public static boolean usernameExists (String username) {
        for (User user :
                users) {
            if (user.getUsername().equals(username)) return true;
        }
        return false;
    }
    public static User accessUser (String username, String password) {
        if (!usernameExists(username)) return null;
        for (User user :
                users) {
            if (user.getUsername().equals(username)) {
                if (user.passwordCheck(password)) return user;
                else return null;
            }
        }
        return null;
    }
    public static User accessUserByName (String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) return user;
        }
        return null;
    }
    public static void removeAccount (User account) {
        users.remove(account);
    }
    public static void removeFood (Foods food) {
        allFoods.remove(food);
    }
    public static String chargeAccount(Matcher matcher, User user) {
        int amount = Integer.parseInt(matcher.group("amount"));
        if (amount == 0 || amount < 0) return "charge account failed: invalid cost or price";
        else {
            user.setBalance(user.getBalance() + amount);
            return "charge account successful";
        }
    }
    public static RestaurantAdmin accessRestaurantByName(String name) {
        for (RestaurantAdmin restaurantAdmin : restaurantAdmins) {
            if (restaurantAdmin.getUsername().equals(name))
                return restaurantAdmin;
        }
        return null;
    }
    public static Foods accessFoodByName(String name, String restaurant) {
        for (Foods food : allFoods) {
            if (food.getName().equals(name) && food.getRestaurantAdmin().getUsername().equals(restaurant))
                return food;
        }
        return null;
    }

    public static String register (LoginMenu loginMenu, Matcher matcher) {
        matcher.matches();
        String username = matcher.group("username");
        if (!Terms.check(username, Terms.VALID_USERNAME)) return "register failed: invalid username format";
        if (usernameExists(username)) return "register failed: username already exists";
        String password = matcher.group("password");
        if (!Terms.check(password, Terms.VALID_PASSWORD)) return "register failed: invalid password format";
        if (!Terms.check(password, Terms.STRONG_PASSWORD)) return "register failed: weak password";
        user = new Customer(username, password);
        return "register successful";
    }

    public static String login (LoginMenu loginMenu, Matcher matcher) {
        matcher.matches();
        String username = matcher.group("username");
        if (!usernameExists(username)) return "login failed: username not found";
        String password = matcher.group("password").trim();
        if (accessUser(username, password) == null) return "login failed: incorrect password";
        user = accessUser(username, password);
        return "login successful";
    }

    public static String changePassword(Matcher matcher) {
        matcher.matches();
        String username = matcher.group("username");
        String oldPassword = matcher.group("oldPassword");
        String newPassword = matcher.group("newPassword");
        if (!usernameExists(username)) return "password change failed: username not found";
        if (accessUser(username, oldPassword) == null) return "password change failed: incorrect password";
        if (!Terms.check(newPassword, Terms.VALID_PASSWORD)) return "password change failed: invalid new password";
        if (!Terms.check(newPassword, Terms.STRONG_PASSWORD)) return "password change failed: weak new password";
        if(accessUser(username, oldPassword).changePassword(oldPassword, newPassword)) return "password change successful";
        return null;
    }

    public static String removeAccount(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!usernameExists(username)) return "remove account failed: username not found";
        if (accessUser(username, password) == null) return "remove account failed: incorrect password";
        removeAccount(accessUser(username, password));
        return "remove account successful";
    }

    public static String removeFood(Matcher matcher, RestaurantAdmin restaurantAdmin) {
        String name = matcher.group("name").trim();
        if (accessFoodByName(name, restaurantAdmin.getUsername()) == null) return "remove food failed: food not found";
        restaurantAdmin.getFoodsOfRestaurant().remove(accessFoodByName(name, restaurantAdmin.getUsername()));
        removeFood(accessFoodByName(name, restaurantAdmin.getUsername()));
        return null;
    }

    public static String addFood(Matcher matcher, User user) {
        String name = matcher.group("name").trim();
        String category = matcher.group("category").trim();
        int price = Integer.parseInt(matcher.group("price").trim());
        int cost = Integer.parseInt(matcher.group("cost").trim());
        if (!Terms.check(category.trim(), Terms.CATEGORY_VALIDATION)) return "add food failed: invalid category";
        if (! Terms.check(name, Terms.TYPE_VALIDATION)) return "add food failed: invalid food name";
        if (foodName(name) != null && foodName(name).getRestaurantAdmin().getUsername().equals(user.getUsername())) return "add food failed: food already exists";
        if (price == 0 || price < 0 || cost == 0 || cost < 0) return "add food failed: invalid cost or price";
        Foods food = new Foods(name, category, price, cost, (RestaurantAdmin) user);
        return "add food successful";
    }

    public static String addRestaurant(Matcher matcher) {
        String username = matcher.group("name").trim();
        String password = matcher.group("password").trim();
        String type = matcher.group("type").trim();
        if (!Terms.check(username, Terms.VALID_USERNAME)) return "add restaurant failed: invalid username format";
        if (usernameExists(username)) return "add restaurant failed: username already exists";
        if (!Terms.check(password, Terms.VALID_PASSWORD)) return "add restaurant failed: invalid password format";
        if (!Terms.check(password, Terms.STRONG_PASSWORD)) return "add restaurant failed: weak password";
        if (!Terms.check(type, Terms.TYPE_VALIDATION)) return "add restaurant failed: invalid type format";
        else {
            RestaurantAdmin restaurantAdmin = new RestaurantAdmin(username, password, type);
            return "add restaurant successful";
        }
    }

    public static String removeRestaurant(Matcher matcher) {
        String name = matcher.group("name");
        if (!usernameExists(name) || !(accessUserByName(name) instanceof RestaurantAdmin)) return "remove restaurant failed: restaurant not found";
        else {
            getRestaurantAdmins().remove(accessUserByName(name));
            removeAccount(accessUserByName(name));
        }
        return null;
    }

    public static String setDiscount(Matcher matcher) {
        String username = matcher.group("username").trim();
        int amount = Integer.parseInt(matcher.group("amount"));
        String code = matcher.group("code");
        if (!usernameExists(username) || !(accessUserByName(username) instanceof Customer)) return "set discount failed: username not found";
        else if (amount == 0 || amount < 0) return "set discount failed: invalid amount";
        else if (!Terms.check(code, Terms.DISCOUNT_VALIDATION)) return "set discount failed: invalid code format";
        else {
            Discount discount = new Discount(username, code, amount);
            return "set discount successful";
        }
    }

    public static String showDiscount() {
        StringBuilder output = new StringBuilder();
        int index = 1;
        boolean first = true;
        for (int i = 0; i < Discount.getAllDiscounts().size(); i++) {
            if (!first) output.append("\n");
            first = false;
            output.append(index);
            output.append(") ");
            output.append(Discount.getAllDiscounts().get(i).getCode());
            output.append(" | amount=");
            output.append(Discount.getAllDiscounts().get(i).getAmount());
            output.append(" --> user=");
            output.append(Discount.getAllDiscounts().get(i).getUsername());
            index++;
        }
        return output.toString();
    }

    public static String showRestaurantMenu(Matcher matcher, Customer user) {
        String restaurantName = matcher.group("restaurantName");
        String category = null;
        if (matcher.group("category") != null)
            category = matcher.group("category").trim();
        if (accessRestaurantByName(restaurantName) == null) return "show menu failed: restaurant not found";
        StringBuilder output = new StringBuilder();
        StringBuilder output1 = new StringBuilder();
        output1.append("<< STARTER >>");
        StringBuilder output2 = new StringBuilder();
        output2.append("<< ENTREE >>");
        StringBuilder output3 = new StringBuilder();
        output3.append("<< DESSERT >>");
        if (category == null) {
            for (int i = 0; i < accessRestaurantByName(restaurantName).getFoodsOfRestaurant().size(); i++) {
                if (accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getCategory().equals("starter")) {
                output1.append("\n").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getName());
                output1.append(" | price=").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getPrice());
                }
            }
            for (int i = 0; i < accessRestaurantByName(restaurantName).getFoodsOfRestaurant().size(); i++) {
                if (accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getCategory().equals("entree")) {
                    output2.append("\n").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getName());
                    output2.append(" | price=").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getPrice());
                }
            }
            for (int i = 0; i < accessRestaurantByName(restaurantName).getFoodsOfRestaurant().size(); i++) {
                if (accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getCategory().equals("dessert")) {
                    output3.append("\n").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getName());
                    output3.append(" | price=").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getPrice());
                }
            }
            output = new StringBuilder(output1 + "\n" + output2 + "\n" + output3);
        }
        else {
            if (!Terms.check(category, Terms.CATEGORY_VALIDATION)) return "show menu failed: invalid category";
            boolean first = true;
            for (int i = 0; i < accessRestaurantByName(restaurantName).getFoodsOfRestaurant().size(); i++) {
                if (accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getCategory().equals(category)) {
                    if (!first) output.append("\n");
                    first = false;
                    output.append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getName());
                    output.append(" | price=").append(accessRestaurantByName(restaurantName).getFoodsOfRestaurant().get(i).getPrice());
                }
            }
        }
        return output.toString();
    }

    public static String addToCart(Matcher matcher, Customer user) {
        String restaurantName = matcher.group("restaurantName").trim();
        String foodName = matcher.group("foodName").trim();
        int count = 1;
        String number = matcher.group("number");
        if (accessRestaurantByName(restaurantName) == null) return "add to cart failed: restaurant not found";
        if (! accessRestaurantByName(restaurantName).getFoodsOfRestaurant().contains(accessFoodByName(foodName, restaurantName)))
            return "add to cart failed: food not found";
        if (number != null) {
            count = Integer.parseInt(number);
            if (count <= 0) return "add to cart failed: invalid number";
        }
        RestaurantAdmin restaurantAdmin = accessRestaurantByName(restaurantName);
        Foods food = accessFoodByName(foodName, restaurantName);
        Cart cart;
        if (!user.getCart().contains(user.getCartFoodCount(food, restaurantAdmin)))
            cart = new Cart(user, restaurantName, foodName, count);
        else {
            user.getCartFoodCount(food, restaurantAdmin).setCount(user.getCartFoodCount(food, restaurantAdmin).getCount() + count);
        }
        return "add to cart successful";
    }

    public static String removeFromCart(Matcher matcher, Customer customer) {
        String restaurantName = matcher.group("restaurantName");
        RestaurantAdmin restaurantAdmin = accessRestaurantByName(restaurantName);
        String foodName = matcher.group("foodName");
        Foods food = accessFoodByName(foodName, restaurantName);
        int count = 1;
        if (matcher.group("number") != null) { count = Integer.parseInt(matcher.group("number").trim()); }
        if (customer.getCartFoodCount(food, restaurantAdmin) == null) return "remove from cart failed: not in cart";
        if (count == 0 || count < 0) return "remove from cart failed: invalid number";
        if (customer.getCartFoodCount(food, restaurantAdmin).getCount() < count) return "remove from cart failed: not enough food in cart";
        customer.getCartFoodCount(food, restaurantAdmin).setCount(customer.getCartFoodCount(food, restaurantAdmin).getCount() - count);
        if (customer.getCartFoodCount(food, restaurantAdmin).getCount() == 0)
            customer.removeFromCart(customer.getCartFoodCount(food, restaurantAdmin));
        return "remove from cart successful";
    }

    public static String showCart(Customer customer) {
        StringBuilder output = new StringBuilder();
        int total = 0;
        int index = 1;
        for (int i = 0; i < customer.getCart().size(); i++) {
            output.append(index).append(") ").append(customer.getCart().get(i).getFood().getName());
            output.append(" | restaurant=").append(customer.getCart().get(i).getRestaurantAdmin().getUsername());
            output.append(" price=").append((customer.getCart().get(i).getFood().getPrice() * customer.getCart().get(i).getCount()));
            index++;
            total += (customer.getCart().get(i).getFood().getPrice() * customer.getCart().get(i).getCount());
            if (i != (customer.getCart().size() - 1))
                output.append("\n");
        }
        if (customer.getCart().isEmpty())
            return "Total: 0";
        else
            output.append("\nTotal: ").append(total);
        return output.toString();
    }

    public static String showDiscount(Customer user) {
        StringBuilder output = new StringBuilder();
        int index = 1;
        for (int i = 0; i < Discount.getUsersDiscount(user).size(); i++) {
            output.append(index).append(") ").append(Discount.getUsersDiscount(user).get(i).getCode());
            output.append(" | amount=").append(Discount.getUsersDiscount(user).get(i).getAmount());
            index++;
            if (i != (Discount.getUsersDiscount(user).size() - 1))
                output.append("\n");
        }
        return output.toString();
    }

    public static String purchaseCart(Matcher matcher, Customer customer) {
        String number = null;
        if (matcher.group("discountCode") != null) {
            number = matcher.group("discountCode");
            if (!Discount.getAllDiscounts().contains(Discount.getDiscountByCode(number))) return "purchase failed: invalid discount code";
        }
        int cashNeeded = 0;
        RestaurantAdmin restaurantAdmin = null;
        int hazineXazaHa = 0;
        for (int i = 0; i < customer.getCart().size(); i++) {
            cashNeeded += (customer.getCart().get(i).getFood().getPrice() * customer.getCart().get(i).getCount());
        }
        if (number != null) {
            cashNeeded -= Discount.getDiscountByCode(number).getAmount();
        }
        if (customer.getBalance() < cashNeeded) return "purchase failed: inadequate money";
        for (int i = 0; i < customer.getCart().size(); i++) {
            restaurantAdmin = customer.getCart().get(i).getRestaurantAdmin();
            customer.getCart().get(i).getRestaurantAdmin().setBalance(restaurantAdmin.getBalance() + ((customer.getCart().get(i).getFood().getPrice() - customer.getCart().get(i).getFood().getCost()) * customer.getCart().get(i).getCount()));
        }
        customer.setBalance(customer.getBalance() - cashNeeded);
        customer.getCart().clear();
        Discount.removeDiscount(Discount.getDiscountByCode(number));
        return "purchase successful";
    }
}
