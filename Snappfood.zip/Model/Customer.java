package Model;
import java.util.ArrayList;
import java.util.HashMap;

public class Customer extends User {
    private ArrayList<Cart> cart;
    public Customer (String username, String password) {
        super (username, password);
        cart = new ArrayList<>();
    }

    public ArrayList<Model.Cart> getCart() {
        return cart;
    }

    public void addCart(Cart cart) {
        this.cart.add(cart);
    }
    public Cart getCartFoodCount(Foods food, RestaurantAdmin  restaurantAdmin) {
        for (int i = 0; i < this.cart.size(); i++) {
            if (this.cart.get(i).getFood().equals(food))
                return this.cart.get(i);
        }
        return null;
    }
    public void removeFromCart(Cart cart) {
        this.cart.remove(cart);
    }
}
