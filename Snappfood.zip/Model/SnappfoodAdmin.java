package Model;

public class SnappfoodAdmin extends User {
    public SnappfoodAdmin (String username, String password) {
        super (username, password);
    }

}
