package Model;

import Controller.Snappfood;

public class Cart {
    private Customer customer;
    private RestaurantAdmin restaurantAdmin;
    private Foods food;
    private int count;

    public Cart(Customer customer, String restaurantName, String foodName, int count) {
        this.customer = customer;
        this.restaurantAdmin = Snappfood.accessRestaurantByName(restaurantName);
        this.food = Snappfood.accessFoodByName(foodName, restaurantName);
        this.count = count;
        customer.addCart(this);
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public RestaurantAdmin getRestaurantAdmin() {
        return restaurantAdmin;
    }

    public void setRestaurantAdmin(RestaurantAdmin restaurantAdmin) {
        this.restaurantAdmin = restaurantAdmin;
    }

    public Foods getFood() {
        return food;
    }

    public void setFood(Foods food) {
        this.food = food;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
