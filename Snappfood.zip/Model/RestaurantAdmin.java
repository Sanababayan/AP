package Model;

import Controller.Snappfood;

import java.util.ArrayList;

public class RestaurantAdmin extends User {
    private String type;
    private ArrayList<Foods> foodsOfRestaurant;
    public RestaurantAdmin (String username, String password, String type) {
        super (username, password);
        this.type = type;
        foodsOfRestaurant = new ArrayList<>();
        Snappfood.addRestaurantAdmin(this);
    }

    public String getType() {
        return type;
    }

    public static String showRestaurantsBasedOnType(String type, User user, int flag) {
        StringBuilder output = new StringBuilder();
        int index = 1;
        if (flag == 1) {
            boolean first = true;
            for (int i = 0; i < Snappfood.getRestaurantAdmins().size(); i++) {
                if (Snappfood.getRestaurantAdmins().get(i).type.equals(type)) {
                    if (!first) output.append("\n");
                    first = false;
                    output.append(index);
                    output.append(") ");
                    output.append(Snappfood.getRestaurantAdmins().get(i).getUsername());
                    output.append(": type=");
                    output.append(type);
                    output.append(" balance=");
                    output.append(Snappfood.getRestaurantAdmins().get(i).getBalance());
                    index++;
                }
            }
        }
        else if (flag == 2){
            boolean first = true;
            for (int i = 0; i < Snappfood.getRestaurantAdmins().size(); i++) {
                if (Snappfood.getRestaurantAdmins().get(i).type.equals(type)) {
                    if (!first) output.append("\n");
                    first = false;
                    output.append(index);
                    output.append(") ");
                    output.append(Snappfood.getRestaurantAdmins().get(i).getUsername());
                    output.append(": type=");
                    output.append(type);
                    index++;
                }
            }
        }
        else if (flag == 3) {
            for (int i = 0; i < Snappfood.getRestaurantAdmins().size(); i++) {
                output.append(index);
                output.append(") ");
                output.append(Snappfood.getRestaurantAdmins().get(i).getUsername());
                output.append(": type=").append(Snappfood.getRestaurantAdmins().get(i).getType());
                if (i != (Snappfood.getRestaurantAdmins().size() - 1))
                    output.append("\n");
                index++;
            }
        }
        else if (flag == 4) {
            for (int i = 0; i < Snappfood.getRestaurantAdmins().size(); i++) {
                output.append(index);
                output.append(") ");
                output.append(Snappfood.getRestaurantAdmins().get(i).getUsername());
                output.append(": type=").append(Snappfood.getRestaurantAdmins().get(i).getType());
                output.append(" balance=");
                output.append(Snappfood.getRestaurantAdmins().get(i).getBalance());
                if (i != (Snappfood.getRestaurantAdmins().size() - 1))
                    output.append("\n");
                index++;
            }
        }
        return output.toString();
    }
    public ArrayList<Foods> getFoodsOfRestaurant() {
        return foodsOfRestaurant;
    }
    public void addFoodsOfRestaurant(Foods foodsOfRestaurant) {
        this.foodsOfRestaurant.add(foodsOfRestaurant);
    }
}
