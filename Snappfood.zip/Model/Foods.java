package Model;

import Controller.Snappfood;

public class Foods {
    private String name;
    private String category;
    private int price;
    private int cost;
    private RestaurantAdmin restaurantAdmin;

    public Foods(String name, String category, int price, int cost, RestaurantAdmin restaurantAdmin) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.cost = cost;
        this.restaurantAdmin = restaurantAdmin;
        restaurantAdmin.addFoodsOfRestaurant(this);
        Snappfood.addAllFoods(this);
    }

    public RestaurantAdmin getRestaurantAdmin() {
        return restaurantAdmin;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
