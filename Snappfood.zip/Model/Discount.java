package Model;

import Controller.Snappfood;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Objects;

public class Discount {
    private String username;
    private String code;
    private int amount;
    private static ArrayList<Discount> allDiscounts = new ArrayList<>();
    public Discount(String username, String code, int amount) {
        this.username = username;
        this.code = code;
        this.amount = amount;
        allDiscounts.add(this);
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public static ArrayList<Discount> getAllDiscounts() {
        return allDiscounts;
    }

    public static void addAllDiscounts(Discount discount) {
        allDiscounts.add(discount);
    }
    public static Discount getDiscountByCode(String code) {
        for (int i = 0; i < allDiscounts.size(); i++) {
            if (allDiscounts.get(i).getCode().equals(code)) return allDiscounts.get(i);
        }
        return null;
    }
    public static ArrayList<Discount> getUsersDiscount(User user) {
        ArrayList<Discount> output = new ArrayList<>();
        for (int i = 0; i < allDiscounts.size(); i++) {
            if (allDiscounts.get(i).getUsername().equals(user.getUsername()))
                output.add(allDiscounts.get(i));
        }
        return output;
    }
    public static void removeDiscount(Discount discount) {
        allDiscounts.remove(discount);
    }
}
