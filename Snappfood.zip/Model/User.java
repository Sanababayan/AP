package Model;

import Controller.Snappfood;

public class User {
    private String username;
    private String password;
    private int balance;


    public User (String username, String password) {
        this.password = password;
        this.username = username;
        this.balance = 0;
        Snappfood.addUser(this);
    }
    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getBalance() {
        return balance;
    }
    public boolean passwordCheck (String password) {
        return this.password.equals(password);
    }

    public String getUsername() {
        return username;
    }
    public boolean changePassword(String oldPassword, String newPassword) {
        if(!this.passwordCheck(oldPassword)) return false;
        this.password = newPassword;
        return true;
    }
}