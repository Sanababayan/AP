import Controller.Snappfood;
import Model.SnappfoodAdmin;
import View.LoginMenu;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String snappfoodAdminUsername = scanner.nextLine();
        String snappfoodAdminPassword = scanner.nextLine();
        Snappfood.setAdmin(new SnappfoodAdmin(snappfoodAdminUsername, snappfoodAdminPassword));
        LoginMenu loginMenu = new LoginMenu();
        loginMenu.run(scanner);
    }
}