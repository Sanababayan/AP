package View;

import Controller.Commands;
import Controller.Snappfood;

import java.util.Scanner;

public class LoginMenu {
    public void run (Scanner scanner) {
        String vorodi;
        while (true) {
            vorodi = scanner.nextLine();
            if (Commands.matches(vorodi, Commands.LOGIN_REGISTER)) {
                System.out.println (Snappfood.register(this, Commands.getMatcher(vorodi, Commands.LOGIN_REGISTER)));
            }
            else if (Commands.matches(vorodi, Commands.LOGIN_LOGIN)) {
                String result = Snappfood.login(this, Commands.getMatcher(vorodi, Commands.LOGIN_LOGIN));
                System.out.println (result);
                if (result.equals("login successful")) {
                    MainMenu mainMenu = new MainMenu();
                    mainMenu.run(scanner, Snappfood.user);
                }
            }
            else if (Commands.matches(vorodi, Commands.LOGIN_CHANGE_PASSWORD)) {
                System.out.println(Snappfood.changePassword(Commands.getMatcher(vorodi, Commands.LOGIN_CHANGE_PASSWORD)));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("login menu");
            }
            else if (Commands.matches(vorodi, Commands.LOGIN_REMOVE_ACCOUNT)) {
                System.out.println(Snappfood.removeAccount(Commands.getMatcher(vorodi, Commands.LOGIN_REMOVE_ACCOUNT)));
            }
            else if (Commands.matches(vorodi, Commands.LOGIN_EXIT)) { break; }
            else {
                System.out.println("invalid command!");
            }
        }
    }
}
