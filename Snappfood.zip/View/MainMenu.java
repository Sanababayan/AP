package View;

import Controller.Commands;
import Controller.Terms;
import Model.Customer;
import Model.RestaurantAdmin;
import Model.SnappfoodAdmin;
import Model.User;
import java.util.Scanner;

public class MainMenu {
    public void run (Scanner scanner, User user) {
        String vorodi;
        while (true) {
            vorodi = scanner.nextLine();
            if(Commands.matches(vorodi.trim(), Commands.MAIN_ENTER)) {
                String menuName = Commands.getMatcher(vorodi.trim(), Commands.MAIN_ENTER).group("menuName");
                if (Terms.check(menuName.trim(), Terms.CUSTOMER_MENU)) {
                    if (user instanceof Customer) {
                        System.out.println("enter menu successful: You are in the customer menu!");
                        CustomerMenu customerMenu = new CustomerMenu();
                        customerMenu.run(scanner, (Customer)user);
                        return;
                    }
                    else {
                        System.out.println("enter menu failed: access denied");
                    }
                }
                else if (Terms.check(menuName, Terms.RESTAURANT_ADMIN_MENU)) {
                    if (user instanceof RestaurantAdmin) {
                        System.out.println("enter menu successful: You are in the restaurant admin menu!");
                        RestaurantAdminMenu restaurantAdminMenu = new RestaurantAdminMenu();
                        restaurantAdminMenu.run(scanner, (RestaurantAdmin) user);
                        return;
                    }
                    else {
                        System.out.println("enter menu failed: access denied");
                    }
                }
                else if (Terms.check(menuName, Terms.SNAPPFOOD_ADMIN_MENU)) {
                    if (user instanceof SnappfoodAdmin) {
                        System.out.println("enter menu successful: You are in the Snappfood admin menu!");
                        SnappfoodAdminMenu snappfoodAdminMenu = new SnappfoodAdminMenu();
                        snappfoodAdminMenu.run(scanner, (SnappfoodAdmin) user);
                        return;
                    }
                    else {
                        System.out.println("enter menu failed: access denied");
                    }
                }
                else {
                    System.out.println("enter menu failed: invalid menu name");
                }
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("main menu");
            }
            else if (Commands.matches(vorodi, Commands.LOGOUT)) { break; }
            else { System.out.println("invalid command!"); }
        }
    }
}
