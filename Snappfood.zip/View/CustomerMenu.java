package View;

import Controller.Commands;
import Controller.Snappfood;
import Model.*;
import java.util.Scanner;

public class CustomerMenu {
    public static void run(Scanner scanner, Customer user) {
        String vorodi;
        while (true) {
            vorodi = scanner.nextLine();
            if(Commands.matches(vorodi, Commands.RESTAURANT_CHARGE_ACCOUNT)) {
                System.out.println(Snappfood.chargeAccount(Commands.getMatcher(vorodi, Commands.RESTAURANT_CHARGE_ACCOUNT), user));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("customer menu");
            }
            else if (Commands.matches(vorodi, Commands.SHOW_BALANCE)) {
                System.out.println(user.getBalance());
            }
            else if (Commands.matches(vorodi, Commands.SHOW_RESTAURANT)) {
                String type = Commands.getMatcher(vorodi, Commands.SHOW_RESTAURANT).group("type");
                String result;
                if (type != null)
                    result = RestaurantAdmin.showRestaurantsBasedOnType(type.trim(), user, 2);
                else
                    result = RestaurantAdmin.showRestaurantsBasedOnType(type, user, 3);
                if (!result.equals("")) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.SHOW_RESTAURANT_MENU)) {
                String result = Snappfood.showRestaurantMenu(Commands.getMatcher(vorodi, Commands.SHOW_RESTAURANT_MENU), user);
                if (!result.equals("")) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.ADD_TO_CART)) {
                System.out.println(Snappfood.addToCart(Commands.getMatcher(vorodi, Commands.ADD_TO_CART), user));
            }
            else if (Commands.matches(vorodi, Commands.REMOVE_FROM_CART)) {
                System.out.println(Snappfood.removeFromCart(Commands.getMatcher(vorodi, Commands.REMOVE_FROM_CART), user));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_DISCOUNT)) {
                String result = Snappfood.showDiscount(user);
                if (!result.equals("")) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.PURCHASE_CART)) {
                System.out.println(Snappfood.purchaseCart(Commands.getMatcher(vorodi, Commands.PURCHASE_CART), user));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CART)) {
                System.out.println(Snappfood.showCart(user));
            }
            else if (Commands.matches(vorodi, Commands.LOGOUT)) { break; }
            else { System.out.println("invalid command!"); }
        }
    }
}
