package View;

import Controller.Commands;
import Controller.Snappfood;
import Model.RestaurantAdmin;
import Model.SnappfoodAdmin;

import java.util.Scanner;

public class SnappfoodAdminMenu {
    public static void run(Scanner scanner, SnappfoodAdmin user) {
        String vorodi;
        while (true) {
            vorodi = scanner.nextLine();
            if (Commands.matches(vorodi, Commands.SNAPPFOOD_ADMIN_ADD_RESTAURANT)) {
                System.out.println(Snappfood.addRestaurant(Commands.getMatcher(vorodi, Commands.SNAPPFOOD_ADMIN_ADD_RESTAURANT)));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Snappfood admin menu");
            }
            else if (Commands.matches(vorodi.trim(), Commands.SHOW_RESTAURANT)) {
                String type = Commands.getMatcher(vorodi.trim(), Commands.SHOW_RESTAURANT).group("type");
                String result;
                if (type != null) {
                    type = type.trim();
                    result = RestaurantAdmin.showRestaurantsBasedOnType(type, user, 1);
                }
                else
                    result = RestaurantAdmin.showRestaurantsBasedOnType(type, user, 4);
                if (!result.equals("")) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.REMOVE_RESTAURANT)) {
                if (Snappfood.removeRestaurant(Commands.getMatcher(vorodi, Commands.REMOVE_RESTAURANT)) != null)
                    System.out.println(Snappfood.removeRestaurant(Commands.getMatcher(vorodi, Commands.REMOVE_RESTAURANT)));
            }
            else if (Commands.matches(vorodi, Commands.SET_DISCOUNT)) {
                System.out.println(Snappfood.setDiscount(Commands.getMatcher(vorodi, Commands.SET_DISCOUNT)));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_DISCOUNT)) {
                String result = Snappfood.showDiscount();
                if (!result.equals("")) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.LOGOUT)) { break; }
            else {
                System.out.println("invalid command!");
            }
        }
    }
}
