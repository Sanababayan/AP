package View;

import Controller.Commands;
import Controller.Snappfood;
import Model.RestaurantAdmin;

import java.util.Scanner;

public class RestaurantAdminMenu {
    String vorodi;
    public void run (Scanner scanner, RestaurantAdmin user) {
        while (true) {
            vorodi = scanner.nextLine();
            if(Commands.matches(vorodi, Commands.RESTAURANT_CHARGE_ACCOUNT)) {
                System.out.println(Snappfood.chargeAccount(Commands.getMatcher(vorodi, Commands.RESTAURANT_CHARGE_ACCOUNT), user));
            }
            else if (Commands.matches(vorodi, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("restaurant admin menu");
            }
            else if (Commands.matches(vorodi, Commands.SHOW_BALANCE)) {
                System.out.println(user.getBalance());
            }
            else if (Commands.matches(vorodi, Commands.ADD_FOOD)) {
                System.out.println(Snappfood.addFood(Commands.getMatcher(vorodi, Commands.ADD_FOOD), user));
            }
            else if (Commands.matches(vorodi, Commands.REMOVE_FOOD)) {
                String result = Snappfood.removeFood(Commands.getMatcher(vorodi, Commands.REMOVE_FOOD), (RestaurantAdmin) user);
                if (result != null) System.out.println(result);
            }
            else if (Commands.matches(vorodi, Commands.LOGOUT)) { break; }
            else { System.out.println("invalid command!"); }
        }
    }
}
