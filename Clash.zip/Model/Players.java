package Model;

import java.util.ArrayList;

public class Players {
    private Users user;
    private Castles leftCastels;
    private Castles rightCastls;
    private Castles middleCastls;
    private ArrayList<Troops> playerTroops;
    private ArrayList<Spells> playerSpells;

    public Players(Users user) {
        this.user = user;
        /*this.leftCastels = new Castles(2500, user);
        this.rightCastls = new Castles(2500, user);
        this.middleCastls = new Castles(3600, user);*/
        this.playerTroops = new ArrayList<>();
        this.playerSpells = new ArrayList<>();
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Castles getLeftCastels() {
        return leftCastels;
    }

    public void setLeftCastels(Castles leftCastels) {
        this.leftCastels = leftCastels;
    }

    public Castles getRightCastls() {
        return rightCastls;
    }

    public void setRightCastls(Castles rightCastls) {
        this.rightCastls = rightCastls;
    }

    public Castles getMiddleCastls() {
        return middleCastls;
    }

    public void setMiddleCastls(Castles middleCastls) {
        this.middleCastls = middleCastls;
    }

    public ArrayList<Troops> getPlayerTroops() {
        return playerTroops;
    }

    public void setPlayerTroops(ArrayList<Troops> playerTroops) {
        this.playerTroops = playerTroops;
    }

    public ArrayList<Spells> getPlayerSpells() {
        return playerSpells;
    }

    public void setPlayerSpells(ArrayList<Spells> playerSpells) {
        this.playerSpells = playerSpells;
    }


    public void levelUp () {
        while (this.getUser().getExperience(this.getUser()) > 160 * this.getUser().getLevel(this.getUser()) * this.getUser().getLevel(this.getUser())) {
            this.getUser().setExperience(this.getUser(), this.getUser().getExperience(this.getUser()) - 160 * this.getUser().getLevel(this.getUser()) * this.getUser().getLevel(this.getUser()));
            this.getUser().setLevel(this.getUser(), this.getUser().getLevel(this.getUser()) + 1);
        }
    }

    public void increaseGold (int amount) {
        this.getUser().setGold(this.getUser(), this.getUser().getGold(this.getUser()) + amount);
    }

    public void increaseExperience (int amount) {
        this.getUser().setExperience(this.getUser(), this.getUser().getExperience(this.getUser()) + amount);
    }
}
