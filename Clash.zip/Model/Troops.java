package Model;

public class Troops extends Cards{
    private int maxHitpoint;
    public Troops(String troopName, int damage, int hintpoint,Space space, Users user) {
        super(troopName, damage, hintpoint, space, user);
        this.maxHitpoint = hintpoint;
    }
    public void fight(Cards card) {
        if (card instanceof Troops) {
            if (!card.getUser().equals(this.getUser())) {
                if (card.getDamage() > this.getDamage()) {
                    this.setHintpoint(this.getHintpoint() - (card.getDamage() - this.getDamage()));
                }
                else {
                    card.setHintpoint(card.getHintpoint() - (this.getDamage() - card.getDamage()));
                }
            }
        }
        else if (card instanceof Castles){
            if (card.getHintpoint() != -1 && !card.getUser().equals(this.getUser())) {
                this.setHintpoint(this.getHintpoint() - card.getDamage());
                card.setHintpoint(card.getHintpoint() - this.getDamage());
                if (card.getHintpoint() < 0)
                    card.setHintpoint(0);
            }
        }
        else if (card instanceof Spells) {
            if (card.getUser().equals(this.getUser())) {
                this.setHintpoint(this.getHintpoint() + card.getDamage());
                if (this.getHintpoint() > this.getMaxHitpoint(this)) this.setHintpoint(this.getMaxHitpoint(this));
            }
        }
    }
}
