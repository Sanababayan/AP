package Model;

public class BabyDragon extends Troops{
    public BabyDragon(Space space, Users user) {
        super("Baby Dragon", 1200, 3300,space, user);
    }
}
