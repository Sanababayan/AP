package Model;

public class Castles extends Cards{
    public Castles(Space space, Users user) {
        super("", 500*user.getLevel(user), 2500*user.getLevel(user), space, user);
        if (space.getDirection().equals("middle")) this.setHintpoint(3600*user.getLevel(user));
    }
    public void fight(Cards card) {
        if (this.getHintpoint() != -1 && !card.getUser().equals(this.getUser())) {
            if (card instanceof Troops) {
                card.setHintpoint(card.getHintpoint() - this.getDamage());
                this.setHintpoint(this.getHintpoint() - card.getDamage());
                if (this.getHintpoint() < 0)
                    this.setHintpoint(0);
            }
        }
    }
}
