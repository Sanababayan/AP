package Model;

public class IceWizard extends Troops{
    public IceWizard(Space space, Users user) {
        super("Ice Wizard", 1500, 3500, space, user);
    }
}
