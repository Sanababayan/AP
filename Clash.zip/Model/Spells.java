package Model;

public class Spells extends Cards{
    public Spells(String spellName, int damage, int hitpoint, Space space,  Users user) {
        super(spellName, damage, hitpoint, space, user);
    }
    public void fight(Cards card) {
        if (card instanceof Troops) {
            if (card.getUser().equals(this.getUser()))
                card.setHintpoint(card.getHintpoint() + this.getDamage());
            if (card.getHintpoint() > card.getMaxHitpoint(card))
                card.setHintpoint(card.getMaxHitpoint(card));
        }
    }
}
