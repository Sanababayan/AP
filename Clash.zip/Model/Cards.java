package Model;

public class Cards {
    private long damage;
    private long hintpoint;
    private Users user;
    private String cardname;
    private Space space;
    public Cards(String cardname, long damage, long hintpoint, Space space, Users user) {
        this.damage = damage;
        this.hintpoint = hintpoint;
        this.cardname = cardname;
        space.addSpaceCards(this);
        this.user = user;
    }
    public void fight(Cards card) {}
    public void setSpace(Space space) {
        this.space = space;
    }
    public Space getSpace() {
        return space;
    }
    public long getDamage() {
        return damage;
    }
    public void setDamage(long damage) {
        this.damage = damage;
    }
    public long getHintpoint() {
        return hintpoint;
    }
    public void setHintpoint(long hintpoint) {
        this.hintpoint = hintpoint;
    }
    public Users getUser() {
        return user;
    }
    public void setUser(Users user) {
        this.user = user;
    }
    public String getCardname() {
        return cardname;
    }
    public void setCardname(String cardname) {
        this.cardname = cardname;
    }
    public int getMaxHitpoint(Cards card) {
        if (card instanceof Barbarian) return 2000;
        if (card instanceof BabyDragon) return 3300;
        if (card instanceof IceWizard) return 3500;
        return -1;
    }
}
