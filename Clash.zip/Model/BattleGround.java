package Model;

import Controller.ClashRoyale;

import java.util.ArrayList;
import java.util.HashMap;

public class BattleGround {
    public HashMap<String, ArrayList<Space>> direction;
    private Players host;
    private Players guest;
    private Players whoseTurn;
    private int turns;
    private Players turnInEachRound;
    public int troopMovementsLeft;
    private int turn;
    public boolean playedCard;
    private final int finalTurn;
    private HashMap<String, Castles> hostCastles;
    private HashMap<String, Castles> guestCastles;
    public BattleGround (Players host, Players guest, int turn) {
        direction = new HashMap<>();
        direction.put ("left", new ArrayList<>(15));
        direction.put ("middle", new ArrayList<>(15));
        direction.put ("right", new ArrayList<>(15));
        for (int i = 0; i < 15; i++) {
            direction.get ("left").add (new Space ("left"));
            direction.get ("middle").add (new Space ("middle"));
            direction.get ("right").add (new Space ("right"));
        }
        hostCastles = new HashMap<>();
        guestCastles = new HashMap<>();
        whoseTurn = host;
        this.host = host;
        this.guest = guest;
        turnInEachRound = host;
        troopMovementsLeft = 3;
        this.turn = 1;
        playedCard = false;
        hostCastles.put ("left", new Castles (direction.get ("left").get (0), host.getUser()));
        hostCastles.put ("middle", new Castles (direction.get ("middle").get (0), host.getUser()));
        hostCastles.put ("right", new Castles (direction.get ("right").get (0), host.getUser()));
        guestCastles.put ("left", new Castles (direction.get ("left").get (14), guest.getUser()));
        guestCastles.put ("middle", new Castles (direction.get ("middle").get (14), guest.getUser()));
        guestCastles.put ("right", new Castles (direction.get ("right").get (14), guest.getUser()));
        finalTurn = turn;
    }
    public int cardsToPlay () {
        if (playedCard) return 0;
        else return 1;
    }

    public int getTroopMovementsLeft() {
        return troopMovementsLeft;
    }

    public void setTroopMovementsLeft(int troopMovementsLeft) {
        this.troopMovementsLeft = troopMovementsLeft;
    }
    public int getTurns() {
        return turns;
    }

    public void setTurns(int turns) {
        this.turns = turns;
    }
    public Players getHost() {
        return host;
    }
    public Players getGuest() {
        return guest;
    }
    public String getOpponentHitpoint(Users user) {
        StringBuilder output = new StringBuilder();
        if (this.whoseTurn.getUser().equals(guest.getUser())) {
            output.append("middle castle: ").append(hostCastles.get("middle").getHintpoint());
            output.append("\nleft castle: ").append(hostCastles.get("left").getHintpoint());
            output.append("\nright castle: ").append(hostCastles.get("right").getHintpoint());
        }
        else {
            output.append("middle castle: ").append(guestCastles.get("middle").getHintpoint());
            output.append("\nleft castle: ").append(guestCastles.get("left").getHintpoint());
            output.append("\nright castle: ").append(guestCastles.get("right").getHintpoint());
        }
        return output.toString();
    }

    public Castles opponentsCastles (String direction) {
        if (whoseTurn.getUser().equals (host.getUser())) return guestCastles.get (direction);
        else return hostCastles.get (direction);
    }

    public Players getWhoseTurn() {
        return whoseTurn;
    }

    public ArrayList<Space> getDirection(String lineDirection) {
        return direction.get(lineDirection);
    }
    public boolean anyTroopThere(Space space) {
        for (int i = 0; i < space.getSpaceCards().size(); i++) {
            if (space.getSpaceCards().get(i) instanceof Troops)
                return true;
        }
        return false;
    }
    public Troops firstTroop (Space space) {
        for (int i = 0; i < space.getSpaceCards().size(); i++) {
            if (space.getSpaceCards().get(i) instanceof Troops && space.getSpaceCards().get(i).getUser().equals(whoseTurn.getUser())) return (Troops) space.getSpaceCards().get(i);
        }
        return null;
    }
    private int totalDestruction (HashMap<String, Castles> towers) {
        int result = 0;
        if (towers.get ("left").getHintpoint() == -1) result++;
        if (towers.get ("middle").getHintpoint() == -1) result++;
        if (towers.get ("right").getHintpoint() == -1) result++;
        return result;
    }

    private int totalHP (HashMap<String, Castles> towers) {
        int result = 0;
        result += towers.get ("left").getHintpoint();
        result += towers.get ("right").getHintpoint ();
        result += towers.get ("middle").getHintpoint ();
        result += totalDestruction (towers);
        return result;
    }

    public boolean changeTurn () {
        if (whoseTurn == guest) {
            ClashRoyale.battleGround(this);
            ClashRoyale.azrael(this);
            turn++;
            if (turn > finalTurn || totalDestruction (guestCastles) == 3 || totalDestruction (hostCastles) == 3) {
                host.increaseGold (totalDestruction (guestCastles) * 25);
                guest.increaseGold (totalDestruction (hostCastles) * 25);
                host.increaseExperience (totalHP (hostCastles));
                guest.increaseExperience (totalHP (guestCastles));
                host.levelUp ();
                guest.levelUp ();
                if (totalHP (guestCastles) > totalHP (hostCastles)) System.out.println ("Game has ended. Winner: " + guest.getUser().getUsername(guest.getUser()));
                else if (totalHP (hostCastles) > totalHP (guestCastles)) System.out.println ("Game has ended. Winner: " + host.getUser().getUsername(host.getUser()));
                else System.out.println ("Game has ended. Result: Tie");
                return true;
            }
            System.out.println ("Player " + host.getUser().getUsername(host.getUser()) + " is now playing!");
            whoseTurn = host;
        }
        else {
            System.out.println ("Player " + guest.getUser().getUsername(guest.getUser()) + " is now playing!");
            whoseTurn = guest;
        }
        playedCard = false;
        troopMovementsLeft = 3;
        return false;
    }
}
