package Model;

import java.util.ArrayList;

public class Space {
    private ArrayList<Cards> spaceCards;
    private String direction;

    public Space(String direction) {
        this.direction = direction;
        this.spaceCards = new ArrayList<>();
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public ArrayList<Cards> getSpaceCards() {
        return spaceCards;
    }
    public void removeSpaceCards(Cards card) {
        this.spaceCards.remove(card);
    }
    public void addSpaceCards(Cards spaceCards) {
        this.spaceCards.add(spaceCards);
    }
}
