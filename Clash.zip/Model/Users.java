package Model;

import Controller.ClashRoyale;

import java.util.ArrayList;

public class Users {
    private String username;
    private String password;
    private int gold;
    private int level;
    private int experience;
    private ArrayList<String> userCards;
    private ArrayList<String> battleDeck;
    public Users(String username, String password) {
        this.username = username;
        this.password = password;
        this.gold = 100;
        this.level = 1;
        this.experience = 0;
        this.userCards = new ArrayList<>();
        this.battleDeck = new ArrayList<>(4);
        this.addUserCard(this, "Barbarian");
        this.addUserCard(this, "Fireball");
        this.addBattleDeck(this, "Barbarian");
        this.addBattleDeck(this, "Fireball");
        ClashRoyale.addAllUsers(this);
    }
    public ArrayList<String> getBattleDeck(Users user) {
        return user.battleDeck;
    }
    public boolean getBattleDeckByName(Users user, String cardName) {
        for (int i = 0; i < user.getBattleDeck(user).size(); i++) {
            if (user.getBattleDeck(user).get(i).equals(cardName))
                return true;
        }
        return false;
    }
    public void removeBattleDeck(Users user, String cardName) {
        for (int i = 0; i < user.getBattleDeck(user).size(); i++) {
            if (user.getBattleDeck(user).get(i).equals(cardName))
                user.getBattleDeck(user).remove(cardName);
        }
    }

    public void addBattleDeck(Users user, String cardName) {
        user.getBattleDeck(user).add(cardName);
    }

    public ArrayList<String> getUserCards(Users user) {
        return user.userCards;
    }
    public void removeUserCard(Users user, String cardName) { user.getUserCards(user).remove(cardName); }
    public void addUserCard(Users user, String cardName) {
        user.getUserCards(user).add(cardName);
    }
    public static Users getUserByUsername(String username) {
        for (int i = 0; i < ClashRoyale.getAllUsers().size(); i++) {
            if (ClashRoyale.getAllUsers().get(i).getUsername(ClashRoyale.getAllUsers().get(i)).equals(username))
                return ClashRoyale.getAllUsers().get(i);
        }
        return null;
    }
    public static Users getUserByPassword(String username, String password) {
        for (int i = 0; i < ClashRoyale.getAllUsers().size(); i++) {
            if (ClashRoyale.getAllUsers().get(i).getUsername(ClashRoyale.getAllUsers().get(i)).equals(username) && ClashRoyale.getAllUsers().get(i).getPassword(ClashRoyale.getAllUsers().get(i)).equals(password))
                return ClashRoyale.getAllUsers().get(i);
        }
        return null;
    }
    public String getUsername(Users user) {
        return user.username;
    }

    public void setUsername(Users user, String username) {
        user.username = username;
    }
    public String getPassword(Users user) {
        return user.password;
    }

    public void setPassword(Users user, String password) {
        user.password = password;
    }

    public int getGold(Users user) {
        return user.gold;
    }

    public void setGold(Users user, int gold) {
        user.gold = gold;
    }

    public int getLevel(Users user) {
        return user.level;
    }

    public void setLevel(Users user, int level) {
        user.level = level;
    }

    public int getExperience(Users user) {
        return user.experience;
    }

    public void setExperience(Users user, int experience) {
        user.experience = experience;
    }
    public boolean getCardByName(Users user, String cardName) {
        for (int i = 0; i < user.getUserCards(user).size(); i++) {
            if (user.getUserCards(user).get(i).equals(cardName))
                return true;
        }
        return false;
    }
}
