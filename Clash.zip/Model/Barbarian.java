package Model;

public class Barbarian extends Troops{
    public Barbarian(Space space, Users user) {
        super("Barbarian", 900,2000,space, user);
    }
}
