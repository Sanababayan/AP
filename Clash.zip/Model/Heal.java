package Model;

public class Heal extends Spells{
    public Heal(Space space, Users user) {
        super("Heal", 1000, 2, space, user);
    }
}
