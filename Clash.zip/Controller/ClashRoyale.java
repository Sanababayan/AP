package Controller;

import Model.*;
import View.GameMenu;
import View.MainMenu;

import java.util.*;
import java.util.regex.Matcher;

public class ClashRoyale {
    private static GameMenu currentGame;
    private static BattleGround currentBattleGround;
    private static ArrayList<Users> allUsers = new ArrayList<>();
    public static ArrayList<Users> getAllUsers() {
        return allUsers;
    }
    public static void addAllUsers(Users users) {
        allUsers.add(users);
    }

    public static BattleGround getCurrentBattleGround() {
        return currentBattleGround;
    }

    public static void setCurrentBattleGround(BattleGround currentBattleGround) {
        ClashRoyale.currentBattleGround = currentBattleGround;
    }

    public static String register(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!Validations.check(username, Validations.VALID_USERNAME)) return "Incorrect format for username!";
        if (!Validations.check(password, Validations.VALID_PASSWORD) || (password.charAt(0) >= '0' && password.charAt(0) <= '9')) return "Incorrect format for password!";
        if (Users.getUserByUsername(username) != null) return "Username already exists!";
        Users user = new Users(username, password);
        return ("User " + username + " created successfully!");
    }
    public static String login(Scanner scanner, Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!Validations.check(username, Validations.VALID_USERNAME)) return "Incorrect format for username!";
        if (!Validations.check(password, Validations.VALID_PASSWORD) || (password.charAt(0) >= '0' && password.charAt(0) <= '9')) return "Incorrect format for password!";
        if (Users.getUserByUsername(username) == null) return "Username doesn't exist!";
        if (Users.getUserByPassword(username, password) == null) return "Password is incorrect!";
        MainMenu mainMenu = new MainMenu();
        mainMenu.setCurrentUser(Users.getUserByPassword(username, password));
        System.out.println("User " + username + " logged in!");
        mainMenu.run(scanner);
        return null;
    }

    public static String listOfUsers() {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < getAllUsers().size(); i++) {
            output.append("user ").append(i+1).append(": ").append(getAllUsers().get(i).getUsername(getAllUsers().get(i)));
            if (i != getAllUsers().size() - 1)
                output.append("\n");
        }
        return output.toString();
    }
    private static class sortUsers implements Comparator<Users> {
        public int compare(Users a, Users b) {
            if (a.getLevel(a) != b.getLevel(b)) return b.getLevel(b) - a.getLevel(a);
            if (a.getExperience(a) != b.getExperience(b)) return b.getExperience(b) - a.getExperience(a);
            return a.getUsername(a).compareTo(b.getUsername(b));
        }
    }
    public static ArrayList<Users> scoreboard() {
        ArrayList<Users> usersScoreboard = new ArrayList<>(allUsers);
        usersScoreboard.sort(new sortUsers());
        return usersScoreboard;
    }
    public static int getRank(Users user) {
        for (int i = 0; i < scoreboard().size(); i++) {
            if (scoreboard().get(i).equals(user))
                return (i+1);
        }
        return -1;
    }
    public static String startGame(Users user, Matcher matcher, Scanner scanner) {
        int turnsCount = Integer.parseInt(matcher.group("turnsCount"));
        if (turnsCount <= 4 || turnsCount >= 31) return "Invalid turns count!";
        if (!Validations.check(matcher.group("username"), Validations.VALID_USERNAME)) return "Incorrect format for username!";
        if (Users.getUserByUsername(matcher.group("username")) == null) return "Username doesn't exist!";
        Players host = new Players(user);
        Players guest = new Players(Users.getUserByUsername(matcher.group("username")));
        BattleGround battleGround = new BattleGround(host, guest, turnsCount);
        GameMenu gameMenu = new GameMenu();
        System.out.println("Battle started with user " + matcher.group("username"));
        setCurrentBattleGround(battleGround);
        gameMenu.setCurrentUser(user);
        gameMenu.run(scanner);
        return null;
    }

    public static String changePassword(Users user, Matcher matcher) {
        String oldPassword = matcher.group("oldPassword");
        String newPassword = matcher.group("newPassword");
        if (!user.getPassword(user).equals(oldPassword)) return "Incorrect password!";
        if (!Validations.check(newPassword, Validations.VALID_PASSWORD) || (newPassword.charAt(0) >= '0' && newPassword.charAt(0) <= '9')) return "Incorrect format for new password!";
        user.setPassword(user, newPassword);
        return "Password changed successfully!";
    }
    public static String info(Users user) {
        StringBuilder output = new StringBuilder();
        output.append("username: ").append(user.getUsername(user)).append("\n");
        output.append("password: ").append(user.getPassword(user)).append("\n");
        output.append("level: ").append(user.getLevel(user)).append("\n");
        output.append("experience: ").append(user.getExperience(user)).append("\n");
        output.append("gold: ").append(user.getGold(user)).append("\n");
        output.append("rank: ").append(getRank(user));
        return output.toString();
    }
    public static String removeFromBattleDeck(Users user, Matcher matcher) {
        String cardName = matcher.group("cardName").trim();
        if (!Validations.check(cardName, Validations.VALID_CARD_NAME)) return "Invalid card name!";
        if (!user.getBattleDeckByName(user, cardName)) return "This card isn't in your battle deck!";
        if (user.getBattleDeck(user).size() == 1) return "Invalid action: your battle deck will be empty!";
        //user.removeBattleDeck(user, cardName);
        user.getBattleDeck(user).remove(cardName);
        return ("Card " + cardName + " removed successfully!");
    }
    public static String addToBattleDeck(Users user, Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Validations.check(cardName, Validations.VALID_CARD_NAME)) return "Invalid card name!";
        if (!user.getCardByName(user, cardName)) return "You don't have this card!";
        if (user.getBattleDeckByName(user, cardName)) return "This card is already in your battle deck!";
        if (user.getBattleDeck(user).size() == 4) return "Invalid action: your battle deck is full!";
        user.addBattleDeck(user, cardName);
        return ("Card " + cardName + " added successfully!");
    }
    public static String showBattleDeck(Users user) {
        StringBuilder output = new StringBuilder();
        ArrayList<String> battleDeckArray = user.getBattleDeck(user);
        Collections.sort(battleDeckArray);
        int flag = 0;
        for (int i = 0; i < battleDeckArray.size(); i++) {
            output.append(battleDeckArray.get(i));
            if (i != (battleDeckArray.size() - 1))
                output.append("\n");
        }
        return output.toString();
    }

    public static int getGoldFromCardName(String cardName) {
        if (cardName.equals("Fireball")) return 100;
        else if (cardName.equals("Heal")) return 150;
        else if (cardName.equals("Barbarian")) return 100;
        else if (cardName.equals("Baby Dragon")) return 200;
        else return 180;
    }
    public static String buyCard(Users user, Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Validations.check(cardName, Validations.VALID_CARD_NAME)) return "Invalid card name!";
        if (user.getGold(user) < getGoldFromCardName(cardName)) return ("Not enough gold to buy " + cardName + "!");
        if (user.getCardByName(user, cardName)) return "You have this card!";
        if (cardName.equals("Fireball")) {
            user.addUserCard(user, "Fireball");
            user.setGold(user, (user.getGold(user) - 100));
        }
        else if (cardName.equals("Heal")) {
            user.addUserCard(user, "Heal");
            user.setGold(user, (user.getGold(user) - 150));
        }
        else if (cardName.equals("Barbarian")) {
            user.addUserCard(user, "Barbarian");
            user.setGold(user, (user.getGold(user) - 100));
        }
        else if (cardName.equals("Baby Dragon")) {
            user.addUserCard(user, "Baby Dragon");
            user.setGold(user, (user.getGold(user) - 200));
        }
        else {
            user.addUserCard(user, "Ice Wizard");
            user.setGold(user, (user.getGold(user) - 180));
        }
        return ("Card " + cardName + " bought successfully!");
    }
    public static String sellCard(Users user, Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Validations.check(cardName, Validations.VALID_CARD_NAME)) return "Invalid card name!";
        if (!user.getCardByName(user, cardName)) return "You don't have this card!";
        if (user.getBattleDeckByName(user, cardName)) return "You cannot sell a card from your battle deck!";
        user.removeUserCard(user, cardName);
        user.setGold(user, (int) (user.getGold(user) + Math.floor(0.8 * getGoldFromCardName(cardName))));
        return ("Card " + cardName + " sold successfully!");
    }
    public static String opponentCastleHitpoint(Users user) {
        return currentBattleGround.getOpponentHitpoint(user);
    }
    public static String showLineInfo(Matcher matcher) {
        String lineDirection = matcher.group("lineDirection");
        if (!Validations.check(lineDirection, Validations.VALID_LINE_DIRECTION)) return "Incorrect line direction!";
        StringBuilder output = new StringBuilder();
        output.append(lineDirection).append(" line:");
        for (int i = 0; i < currentBattleGround.getDirection(lineDirection).size(); i++) {
            if (!currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().isEmpty()) {
                for (int j = 0; j < currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().size(); j++) {
                    if (!(currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().get(j) instanceof Castles)) {
                        output.append("\nrow ").append(i + 1).append(": ");
                        output.append(currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().get(j).getCardname());
                        output.append(": ").append(currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().get(j).getUser().getUsername(currentBattleGround.getDirection(lineDirection).get(i).getSpaceCards().get(j).getUser()));
                    }
                }
            }
        }
        return output.toString();
    }
    public static String numberOfCardsToPlay(Users user) {
        if (user.equals(currentBattleGround.getHost().getUser()))
            return ("You can play " + currentBattleGround.cardsToPlay() + " cards more!");
        else if (user.equals(currentBattleGround.getGuest().getUser()))
            return ("You can play " + currentBattleGround.cardsToPlay() + " cards more!");
        return null;
    }
    public static String movementsLeft(Users user) {
        if (user.equals(currentBattleGround.getHost().getUser())) return ("You have " + currentBattleGround.getTroopMovementsLeft() + " moves left!");
        if (user.equals(currentBattleGround.getGuest().getUser())) return ("You have " + currentBattleGround.getTroopMovementsLeft() + " moves left!");
        return null;
    }
    public static String troopMoves(Users user, Matcher matcher) {
        String lineDirection = matcher.group("lineDirection");
        if (!Validations.check(lineDirection, Validations.VALID_LINE_DIRECTION)) return "Incorrect line direction!";
        int rowNumber = Integer.parseInt(matcher.group("rowNumber"));
        if (rowNumber <= 0 || rowNumber >= 16) return "Invalid row number!";
        String direction = matcher.group("direction");
        if (!Validations.check(direction, Validations.VALID_DIRECTION)) return "you can only move troops upward or downward!";
        if (currentBattleGround.getTroopMovementsLeft() == 0) return "You are out of moves!";
        if (currentBattleGround.firstTroop (currentBattleGround.getDirection(lineDirection).get (rowNumber - 1)) == null) return "You don't have any troops in this place!";
        if ((rowNumber == 15 && direction.equals("upward")) || (rowNumber == 1 && direction.equals("downward"))) return "Invalid move!";
        int finalRow = 0;
        Troops tempTroop = currentBattleGround.firstTroop (currentBattleGround.getDirection(lineDirection).get (rowNumber - 1));
        currentBattleGround.getDirection(lineDirection).get (rowNumber - 1).getSpaceCards().remove(tempTroop);
        if (direction.equals("upward")) finalRow = rowNumber + 1;
        else if (direction.equals("downward")) finalRow = rowNumber - 1;
        tempTroop.setSpace(currentBattleGround.getDirection(lineDirection).get (finalRow - 1));
        currentBattleGround.getDirection(lineDirection).get (finalRow - 1).addSpaceCards(tempTroop);
        currentBattleGround.setTroopMovementsLeft(currentBattleGround.getTroopMovementsLeft() - 1);
        return (tempTroop.getCardname() + " moved successfully to row " + finalRow + " in line " + lineDirection);
    }
    public static String deployTroop(Users user, Matcher matcher) {
        String troopName = matcher.group("troopName");
        if (!Validations.check(troopName, Validations.VALID_TROOP_NAME)) return "Invalid troop name!";
        if (!currentBattleGround.getWhoseTurn().getUser().getBattleDeck(currentBattleGround.getWhoseTurn().getUser()).contains(troopName)) return ("You don't have " + troopName + " card in your battle deck!");
        String lineDirection = matcher.group("lineiDrection");
        if (!Validations.check(lineDirection, Validations.VALID_LINE_DIRECTION)) return "Incorrect line direction!";
        int rowNumber = Integer.parseInt(matcher.group("rowNumber"));
        if (rowNumber <= 0 || rowNumber >= 16) return "Invalid row number!";
        if (currentBattleGround.getWhoseTurn().getUser().equals(currentBattleGround.getHost().getUser())) {
            if (rowNumber >= 5) return "Deploy your troops near your castles!";
            if (currentBattleGround.cardsToPlay() == 0) return "You have deployed a troop or spell this turn!";
            else currentBattleGround.playedCard = true;
        }
        else if (currentBattleGround.getWhoseTurn().getUser().equals(currentBattleGround.getGuest().getUser())) {
            if (rowNumber <= 11) return "Deploy your troops near your castles!";
            if (currentBattleGround.cardsToPlay() == 0) return "You have deployed a troop or spell this turn!";
            else currentBattleGround.playedCard = true;
        }
        Space space = currentBattleGround.getDirection(lineDirection).get(rowNumber - 1);
        if (troopName.equals("Baby Dragon")) new BabyDragon (space, currentBattleGround.getWhoseTurn().getUser());
        else if (troopName.equals("Barbarian")) new Barbarian (space, currentBattleGround.getWhoseTurn().getUser());
        else if (troopName.equals("Ice Wizard")) new IceWizard (space, currentBattleGround.getWhoseTurn().getUser());
        return ("You have deployed " + troopName + " successfully!");
    }
    public static String deploySpellHeal(Users user, Matcher matcher) {
        String lineDirection = matcher.group("lineDirection");
        if (!Validations.check(lineDirection, Validations.VALID_LINE_DIRECTION)) return "Incorrect line direction!";
        if (!currentBattleGround.getWhoseTurn().getUser().getBattleDeck(currentBattleGround.getWhoseTurn().getUser()).contains("Heal")) return "You don't have Heal card in your battle deck!";
        int rowNumber = Integer.parseInt(matcher.group("rowNumber"));
        if (rowNumber <= 0 || rowNumber >= 16) return "Invalid row number!";
        if (currentBattleGround.getWhoseTurn().getUser().equals(currentBattleGround.getHost().getUser())) {
            if (currentBattleGround.cardsToPlay() == 0) {
                return "You have deployed a troop or spell this turn!";
            }
            else currentBattleGround.playedCard = true;
        }
        else if (currentBattleGround.getWhoseTurn().getUser().equals(currentBattleGround.getGuest().getUser())) {
            if (currentBattleGround.cardsToPlay() == 0) {
                return "You have deployed a troop or spell this turn!";
            }
            else currentBattleGround.playedCard = true;
        }
        Space space = currentBattleGround.getDirection(lineDirection).get (rowNumber - 1);
        new Heal (space, currentBattleGround.getWhoseTurn().getUser());
        currentBattleGround.playedCard = true;
        return "You have deployed Heal successfully!";
    }
    public static String deployFireball(Users user, Matcher matcher) {
        String lineDirection = matcher.group("lineDirection");
        if (!Validations.check(lineDirection, Validations.VALID_LINE_DIRECTION)) return "Incorrect line direction!";
        if (!currentBattleGround.getWhoseTurn().getUser().getBattleDeck(currentBattleGround.getWhoseTurn().getUser()).contains("Fireball")) return "You don't have Fireball card in your battle deck!";
        if (currentBattleGround.cardsToPlay () == 0) return "You have deployed a troop or spell this turn!";
        if (currentBattleGround.opponentsCastles (lineDirection).getHintpoint () == -1) return "This castle is already destroyed!";
        currentBattleGround.opponentsCastles (lineDirection).setHintpoint (currentBattleGround.opponentsCastles (lineDirection).getHintpoint() - 1600);
        if (currentBattleGround.opponentsCastles (lineDirection).getHintpoint () <= 0)
            currentBattleGround.opponentsCastles (lineDirection).setHintpoint (-1);
        currentBattleGround.playedCard = true;
        return "You have deployed Fireball successfully!";
    }
    /*public static String nextTurn(Users user) {
        if (user.equals(currentBattleGround.getHost().getUser())) {
            GameMenu.setCurrentUser(currentBattleGround.getGuest().getUser());
            return ("Player " + currentBattleGround.getGuest().getUser().getUsername(currentBattleGround.getGuest().getUser()) + " is now playing!");
        }
        else if (user.equals(currentBattleGround.getGuest().getUser())) {
            GameMenu.setCurrentUser(currentBattleGround.getGuest().getUser());
            azrael(currentBattleGround);
            currentBattleGround.setTurns(currentBattleGround.getTurns() - 1);
            System.out.println("Player " + currentBattleGround.getHost().getUser().getUsername(currentBattleGround.getHost().getUser()) + " is now playing!");
            if (currentBattleGround.getTurns() > 0) battleGround(currentBattleGround);
            else {
                return gameEnd(currentBattleGround);
            }
        }
        return null;
    }*/
    public static void battleGround(BattleGround battleGround) {
        for (int i = 0; i < battleGround.direction.get("left").size(); i++) {
            Space leftSpace = battleGround.direction.get("left").get(i);
            for (int j = 0; j < leftSpace.getSpaceCards().size() - 1; j++) {
                for (int k = j+1; k < leftSpace.getSpaceCards().size(); k++) {
                    leftSpace.getSpaceCards().get(j).fight(leftSpace.getSpaceCards().get(k));
                }
            }
        }
        for (int i = 0; i < battleGround.direction.get("right").size(); i++) {
            Space rightSpace = battleGround.direction.get("right").get(i);
            for (int j = 0; j < rightSpace.getSpaceCards().size() - 1; j++) {
                for (int k = j+1; k < rightSpace.getSpaceCards().size(); k++) {
                    rightSpace.getSpaceCards().get(j).fight(rightSpace.getSpaceCards().get(k));
                }
            }
        }
        for (int i = 0; i < battleGround.direction.get("middle").size(); i++) {
            Space middleSpace = battleGround.getDirection("middle").get(i);
            for (int j = 0; j < middleSpace.getSpaceCards().size() - 1; j++) {
                for (int k = j+1; k < middleSpace.getSpaceCards().size(); k++) {
                    middleSpace.getSpaceCards().get(j).fight(middleSpace.getSpaceCards().get(k));
                }
            }
        }
    }
    public static void azrael(BattleGround battleGround) {
        for (int i = battleGround.getDirection("left").size() - 1; i >= 0; i--) {
            Space leftSpace = battleGround.getDirection("left").get(i);
            for (int j = leftSpace.getSpaceCards().size() - 1; j >= 0; j--) {
                if (leftSpace.getSpaceCards().get(j) instanceof Troops) {
                    if (leftSpace.getSpaceCards().get(j).getHintpoint() <= 0) {
                        leftSpace.getSpaceCards().remove(leftSpace.getSpaceCards().get(j));
                    }
                }
                else if (leftSpace.getSpaceCards().get(j) instanceof Spells) {
                    leftSpace.getSpaceCards().get(j).setHintpoint(leftSpace.getSpaceCards().get(j).getHintpoint() - 1);
                    if (((Spells) leftSpace.getSpaceCards().get(j)).getHintpoint() == 0) {
                        leftSpace.getSpaceCards().remove(leftSpace.getSpaceCards().get(j));
                    }
                }
                else if (leftSpace.getSpaceCards().get(j) instanceof Castles) {
                    if (leftSpace.getSpaceCards().get(j).getHintpoint() == 0) {
                        leftSpace.getSpaceCards().get(j).setHintpoint(-1);
                    }
                }
            }
        }
        for (int i = battleGround.getDirection("right").size() - 1; i >= 0; i--) {
            Space rightSpace = battleGround.getDirection("right").get(i);
            for (int j = rightSpace.getSpaceCards().size() - 1; j >= 0; j--) {
                if (rightSpace.getSpaceCards().get(j) instanceof Troops) {
                    if (rightSpace.getSpaceCards().get(j).getHintpoint() <= 0) {
                        rightSpace.getSpaceCards().remove(rightSpace.getSpaceCards().get(j));
                    }
                } else if (rightSpace.getSpaceCards().get(j) instanceof Spells) {
                    rightSpace.getSpaceCards().get(j).setHintpoint(rightSpace.getSpaceCards().get(j).getHintpoint() - 1);
                    if (((Spells) rightSpace.getSpaceCards().get(j)).getHintpoint() == 0) {
                        rightSpace.getSpaceCards().remove(rightSpace.getSpaceCards().get(j));
                    }
                } else if (rightSpace.getSpaceCards().get(j) instanceof Castles) {
                    if (rightSpace.getSpaceCards().get(j).getHintpoint() == 0) {
                        rightSpace.getSpaceCards().get(j).setHintpoint(-1);
                    }
                }
            }
        }
        for (int i = battleGround.getDirection("middle").size() - 1; i >= 0; i--) {
            Space middleSpace = battleGround.getDirection("middle").get(i);
            for (int j = middleSpace.getSpaceCards().size() - 1; j >= 0; j--) {
                if (middleSpace.getSpaceCards().get(j) instanceof Troops) {
                    if (middleSpace.getSpaceCards().get(j).getHintpoint() <= 0) {
                        middleSpace.getSpaceCards().remove(middleSpace.getSpaceCards().get(j));
                    }
                }
                else if(middleSpace.getSpaceCards().get(j) instanceof Spells) {
                    middleSpace.getSpaceCards().get(j).setHintpoint(middleSpace.getSpaceCards().get(j).getHintpoint() - 1);
                    if (((Spells) middleSpace.getSpaceCards().get(j)).getHintpoint() == 0) {
                        middleSpace.getSpaceCards().remove(middleSpace.getSpaceCards().get(j));
                    }
                }
                else if (middleSpace.getSpaceCards().get(j) instanceof Castles) {
                    if (middleSpace.getSpaceCards().get(j).getHintpoint() == 0) {
                        middleSpace.getSpaceCards().get(j).setHintpoint(-1);
                    }
                }
            }
        }
    }
    /*public static String gameEnd(BattleGround battleGround) {
        Players host = battleGround.getHost();
        Players guest = battleGround.getGuest();
        if ((host.getRightCastls() == null && host.getLeftCastels() == null && host.getMiddleCastls() == null) && !(guest.getRightCastls() == null && guest.getLeftCastels() == null && guest.getMiddleCastls() == null)) {
            guest.getUser().setGold(guest.getUser(), guest.getUser().getGold(guest.getUser()) + 75);
            if (guest.getLeftCastels().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getLeftCastels().getHintpoint()));
            if (guest.getRightCastls().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getRightCastls().getHintpoint()));
            if (guest.getMiddleCastls().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getMiddleCastls().getHintpoint()));
            updateUser(host.getUser());
            updateUser(guest.getUser());
            return ("Game has ended. Winner: " + guest.getUser().getUsername(guest.getUser()));
        }
        else if ((guest.getRightCastls() == null && guest.getLeftCastels() == null && guest.getMiddleCastls() == null) && !(host.getRightCastls() == null && host.getLeftCastels() == null && host.getMiddleCastls() == null)) {
            host.getUser().setGold(host.getUser(), host.getUser().getGold(host.getUser()) + 75);
            if (host.getLeftCastels().getHintpoint() != -1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getLeftCastels().getHintpoint()));
            if (host.getRightCastls().getHintpoint() != - 1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getRightCastls().getHintpoint()));
            if (host.getMiddleCastls().getHintpoint() != -1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getMiddleCastls().getHintpoint()));
            updateUser(host.getUser());
            updateUser(guest.getUser());
            return ("Game has ended. Winner: " + host.getUser().getUsername(host.getUser()));
        }
        else if ((guest.getRightCastls() == null && guest.getLeftCastels() == null && guest.getMiddleCastls() == null) && (host.getRightCastls() == null && host.getLeftCastels() == null && host.getMiddleCastls() == null)) {
            guest.getUser().setGold(guest.getUser(), guest.getUser().getGold(guest.getUser()) + 75);
            host.getUser().setGold(host.getUser(), host.getUser().getGold(host.getUser()) + 75);
            return "Game has ended. Result: Tie";
        }
        else {
            if (guest.getLeftCastels().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getLeftCastels().getHintpoint()));
            else
                host.getUser().setGold(host.getUser(), host.getUser().getGold(host.getUser()) + 25);
            if (guest.getRightCastls().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getRightCastls().getHintpoint()));
            else
                host.getUser().setGold(host.getUser(), host.getUser().getGold(host.getUser()) + 25);
            if (guest.getMiddleCastls().getHintpoint() != -1)
                guest.getUser().setExperience(this.getUser(), (int) (guest.getUser().getExperience(guest.getUser()) + guest.getMiddleCastls().getHintpoint()));
            else
                host.getUser().setGold(host.getUser(), host.getUser().getGold(host.getUser()) + 25);
            if (host.getLeftCastels().getHintpoint() != -1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getLeftCastels().getHintpoint()));
            else
                guest.getUser().setGold(guest.getUser(), guest.getUser().getGold(guest.getUser()) + 25);
            if (host.getRightCastls().getHintpoint() != - 1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getRightCastls().getHintpoint()));
            else
                guest.getUser().setGold(guest.getUser(), guest.getUser().getGold(guest.getUser()) + 25);
            if (host.getMiddleCastls().getHintpoint() != -1)
                host.getUser().setExperience(this.getUser(), (int) (host.getUser().getExperience(host.getUser()) + host.getMiddleCastls().getHintpoint()));
            else
                guest.getUser().setGold(guest.getUser(), guest.getUser().getGold(guest.getUser()) + 25);
            int hostHitpoins = (int) (host.getMiddleCastls().getHintpoint() + host.getLeftCastels().getHintpoint() + host.getRightCastls().getHintpoint());
            int guestHitpoins = (int) (guest.getMiddleCastls().getHintpoint() + guest.getLeftCastels().getHintpoint() + guest.getRightCastls().getHintpoint());
            if (hostHitpoins > guestHitpoins) {
                updateUser(host.getUser());
                updateUser(guest.getUser());
                return ("Game has ended. Winner: " + host.getUser().getUsername(host.getUser()));
            }
            else if (hostHitpoins == guestHitpoins) {
                updateUser(host.getUser());
                updateUser(guest.getUser());
                return "Game has ended. Result: Tie"; }
            else {
                updateUser(host.getUser());
                updateUser(guest.getUser());
                return ("Game has ended. Winner: " + guest.getUser().getUsername(guest.getUser()));
            }
        }
    }
    public static void updateUser(Users user) {
        while (true) {
            if (user.getExperience(user) >= (160 * user.getLevel(user) * user.getLevel(user))) {
                user.setExperience(this.getUser(), user.getExperience(user) - (160 * user.getLevel(user) * user.getLevel(user)));
                user.setLevel(user, user.getLevel(user) + 1);
            }
            else break;
        }
    }*/
}
