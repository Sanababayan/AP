package Controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    REGISTER ("^register username (?<username>.*) password (?<password>.*)$"),
    LOGIN("^login username (?<username>.*) password (?<password>.*)$"),
    SHOW_CURRENT_MENU("^show current menu$"),
    EXIT("^Exit$"),
    LIST_OF_USERS("^list of users$"),
    SCOREBOARD("^scoreboard$"),
    LOGOUT("^logout$"),
    PROFILE_MENU("^profile menu$"),
    SHOP_MENU("^shop menu$"),
    START_GAME("^start game turns count (?<turnsCount>-?[0-9]+) username (?<username>.*)$"),
    BACK("^back$"),
    CHANGE_PASSWORD("^change password old password (?<oldPassword>.*) new password (?<newPassword>.*)$"),
    INFO("^Info$"),
    REMOVE_FROM_BATTLE_DECK("^remove from battle deck (?<cardName>.*)$"),
    ADD_TO_BATTLE_DECK("^add to battle deck (?<cardName>.*)$"),
    SHOW_BATTLE_DECK("^show battle deck$"),
    BUY_CARD("^buy card (?<cardName>.*)$"),
    SELL_CARD("^sell card (?<cardName>.*)$"),
    OPPONENT_CASTLE_HITPOINT("^show the hitpoints left of my opponent$"),
    SHOW_LINE_INFO("^show line info (?<lineDirection>.*)$"),
    NUMBER_OF_CARDS_TO_PLAY("^number of cards to play$"),
    MOVEMENTS_LEFT("^number of moves left$"),
    TROOP_MOVES("^move troop in line (?<lineDirection>.*) and row (?<rowNumber>-?[0-9]+) (?<direction>.*)$"),
    DEPLOY_TROOP("^deploy troop (?<troopName>.*) in line (?<lineiDrection>.*) and row (?<rowNumber>-?[0-9]+)$"),
    DEPLOY_SPELL("^deploy spell Heal in line (?<lineDirection>.*) and row (?<rowNumber>.*)$"),
    DEPLOY_FIREBALL("^deploy spell Fireball in line (?<lineDirection>.*)$"),
    NEXT_TURN("^next turn$");
    final String regex;
    private Commands(String regex) {
        this.regex = regex;
    }
    public static boolean matches (String string, Commands command) {
        return Pattern.matches(command.regex, string);
    }
    public static Matcher getMatcher (String string, Commands command) {
        Matcher matcher =Pattern.compile(command.regex).matcher(string);
        matcher.matches();
        return matcher;
    }
}
