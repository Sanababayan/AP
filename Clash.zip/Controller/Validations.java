package Controller;

import java.util.regex.Pattern;

public enum Validations {
    VALID_PASSWORD ("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*!@#$%^&])[^\\s]{8,20}$"),
    VALID_USERNAME("[a-zA-Z]+"),
    VALID_CARD_NAME("(Fireball|Heal|Barbarian|Baby Dragon|Ice Wizard)"),
    VALID_LINE_DIRECTION("(right|left|middle)"),
    VALID_DIRECTION("(upward|downward)"),
    VALID_TROOP_NAME("(Ice Wizard|Barbarian|Baby Dragon)");
    private final String regex;
    private Validations(String regex) {
        this.regex = regex;
    }
    public static boolean check (String string, Validations term) {
        return Pattern.compile(term.regex).matcher(string).matches();
    }
}
