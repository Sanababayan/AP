package View;

import Controller.ClashRoyale;
import Controller.Commands;
import Model.Users;

import java.util.Scanner;

public class ShopMenu {
    private static Users currentUser;
    public void run(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (Commands.matches(input, Commands.BUY_CARD)) {
                System.out.println(ClashRoyale.buyCard(currentUser, Commands.getMatcher(input, Commands.BUY_CARD)));
            }
            else if (Commands.matches(input, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Shop Menu");
            }
            else if (Commands.matches(input, Commands.SELL_CARD)) {
                System.out.println(ClashRoyale.sellCard(currentUser, Commands.getMatcher(input, Commands.SELL_CARD)));
            }
            else if (Commands.matches(input, Commands.BACK)) {
                System.out.println("Entered main menu!");
                break; }
            else {
                System.out.println("Invalid command!");
            }
        }
    }
    public static Users getCurrentUser() {
        return currentUser;
    }
    public static void setCurrentUser(Users currentUser) {
        ShopMenu.currentUser = currentUser;
    }
}
