package View;

import Controller.ClashRoyale;
import Controller.Commands;
import Model.Users;

import java.util.Scanner;
import java.util.regex.Matcher;

public class ProfileMenu {
    private static Users currentUser;
    public void run(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (Commands.matches(input, Commands.CHANGE_PASSWORD)) {
                System.out.println(ClashRoyale.changePassword(currentUser, Commands.getMatcher(input, Commands.CHANGE_PASSWORD)));
            }
            else if (Commands.matches(input, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Profile Menu");
            }
            else if (Commands.matches(input, Commands.INFO)) {
                System.out.println(ClashRoyale.info(currentUser));
            }
            else if (Commands.matches(input, Commands.REMOVE_FROM_BATTLE_DECK)) {
                System.out.println(ClashRoyale.removeFromBattleDeck(currentUser, Commands.getMatcher(input, Commands.REMOVE_FROM_BATTLE_DECK)));
            }
            else if (Commands.matches(input, Commands.ADD_TO_BATTLE_DECK)) {
                System.out.println(ClashRoyale.addToBattleDeck(currentUser, Commands.getMatcher(input, Commands.ADD_TO_BATTLE_DECK)));
            }
            else if (Commands.matches(input, Commands.SHOW_BATTLE_DECK)) {
                System.out.println(ClashRoyale.showBattleDeck(currentUser));
            }
            else if (Commands.matches(input, Commands.BACK)) {
                System.out.println("Entered main menu!");
                break;
            }
            else {
                System.out.println("Invalid command!");
            }
        }
    }
    public static Users getCurrentUser() {
        return currentUser;
    }
    public static void setCurrentUser(Users currentUser) {
        ProfileMenu.currentUser = currentUser;
    }
}
