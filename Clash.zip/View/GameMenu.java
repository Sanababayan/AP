package View;

import Controller.ClashRoyale;
import Controller.Commands;
import Model.Users;

import java.util.Scanner;

public class GameMenu {
    private static Users currentUser;
    public void run(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (Commands.matches(input, Commands.OPPONENT_CASTLE_HITPOINT)) {
                System.out.println(ClashRoyale.opponentCastleHitpoint(getCurrentUser()));
            }
            else if (Commands.matches(input, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Game Menu");
            }
            else if (Commands.matches(input, Commands.SHOW_LINE_INFO)) {
                System.out.println(ClashRoyale.showLineInfo(Commands.getMatcher(input, Commands.SHOW_LINE_INFO)));
            }
            else if (Commands.matches(input, Commands.NUMBER_OF_CARDS_TO_PLAY)) {
                System.out.println(ClashRoyale.numberOfCardsToPlay(getCurrentUser()));
            }
            else if (Commands.matches(input, Commands.MOVEMENTS_LEFT)) {
                System.out.println(ClashRoyale.movementsLeft(getCurrentUser()));
            }
            else if (Commands.matches(input, Commands.TROOP_MOVES)) {
                System.out.println(ClashRoyale.troopMoves(getCurrentUser(), Commands.getMatcher(input, Commands.TROOP_MOVES)));
            }
            else if (Commands.matches(input, Commands.DEPLOY_TROOP)) {
                System.out.println(ClashRoyale.deployTroop(getCurrentUser(), Commands.getMatcher(input, Commands.DEPLOY_TROOP)));
            }
            else if (Commands.matches(input, Commands.DEPLOY_SPELL)) {
                System.out.println(ClashRoyale.deploySpellHeal(getCurrentUser(), Commands.getMatcher(input, Commands.DEPLOY_SPELL)));
            }
            else if (Commands.matches(input, Commands.DEPLOY_FIREBALL)) {
                System.out.println(ClashRoyale.deployFireball(getCurrentUser(), Commands.getMatcher(input, Commands.DEPLOY_FIREBALL)));
            }
            else if (Commands.matches(input, Commands.NEXT_TURN)) {
                if (ClashRoyale.getCurrentBattleGround().changeTurn()) break;
            }
            else if (Commands.matches(input, Commands.BACK)) {
                System.out.println("Entered main menu!");
                break;
            }
            else {
                System.out.println("Invalid command!");
            }
        }
    }
    public static Users getCurrentUser() {
        return currentUser;
    }
    public static void setCurrentUser(Users currentUser) {
        GameMenu.currentUser = currentUser;
    }
}
