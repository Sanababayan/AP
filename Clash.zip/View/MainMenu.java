package View;

import Controller.ClashRoyale;
import Controller.Commands;
import Model.Users;

import java.util.ArrayList;
import java.util.Scanner;

public class MainMenu {
    private static Users currentUser;
    public void run(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (Commands.matches(input, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Main Menu");
            }
            else if (Commands.matches(input, Commands.LIST_OF_USERS)) {
                if (ClashRoyale.listOfUsers() != null)
                    System.out.println(ClashRoyale.listOfUsers());
            }
            else if (Commands.matches(input, Commands.SCOREBOARD)) {
                ArrayList<Users> output = ClashRoyale.scoreboard();
                StringBuilder score = new StringBuilder();
                if (output.size() < 5) {
                    for (int i = 0; i < output.size(); i++) {
                        if (i != 0)
                            score.append("\n").append(i+1).append("- username: ").append(output.get(i).getUsername(output.get(i)));
                        else
                            score.append(i+1).append("- username: ").append(output.get(i).getUsername(output.get(i)));
                        score.append(" level: ").append(output.get(i).getLevel(output.get(i)));
                        score.append(" experience: ").append(output.get(i).getExperience(output.get(i)));
                    }
                }
                else {
                    for (int i = 0; i < 5; i++) {
                        if (i != 0)
                            score.append("\n").append(i+1).append("- username: ").append(output.get(i).getUsername(output.get(i)));
                        else
                            score.append(i+1).append("- username: ").append(output.get(i).getUsername(output.get(i)));
                        score.append(" level: ").append(output.get(i).getLevel(output.get(i)));
                        score.append(" experience: ").append(output.get(i).getExperience(output.get(i)));
                    }
                }
                System.out.println(score.toString());
            }
            else if (Commands.matches(input, Commands.LOGOUT)) {
                System.out.println("User " + getCurrentUser().getUsername(getCurrentUser()) + " logged out successfully!");
                break;
            }
            else if (Commands.matches(input, Commands.PROFILE_MENU)) {
                ProfileMenu profileMenu = new ProfileMenu();
                profileMenu.setCurrentUser(currentUser);
                System.out.println("Entered profile menu!");
                profileMenu.run(scanner);
            }
            else if (Commands.matches(input, Commands.SHOP_MENU)) {
                ShopMenu shopMenu = new ShopMenu();
                ShopMenu.setCurrentUser(currentUser);
                System.out.println("Entered shop menu!");
                shopMenu.run(scanner);
            }
            else if (Commands.matches(input, Commands.START_GAME)) {
                String result = ClashRoyale.startGame(currentUser, Commands.getMatcher(input, Commands.START_GAME), scanner);
                if (result != null)
                    System.out.println(result);
            }
            else {
                System.out.println("Invalid command!");
            }
        }
    }

    public static Users getCurrentUser() {
        return currentUser;
    }
    public static void setCurrentUser(Users user) {
        MainMenu.currentUser = user;
    }
}
