package View;

import Controller.ClashRoyale;
import Controller.Commands;
import Controller.Validations;
import Model.Users;

import java.util.Scanner;

public class LoginMenu {
    public void run(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (Commands.matches(input, Commands.REGISTER)) {
                System.out.println(ClashRoyale.register(Commands.getMatcher(input, Commands.REGISTER)));
            }
            else if (Commands.matches(input, Commands.LOGIN)) {
                if (ClashRoyale.login(scanner, Commands.getMatcher(input, Commands.LOGIN)) != null)
                    System.out.println(ClashRoyale.login(scanner, Commands.getMatcher(input, Commands.LOGIN)));
            }
            else if (Commands.matches(input, Commands.SHOW_CURRENT_MENU)) {
                System.out.println("Register/Login Menu");
            }
            else if (Commands.matches(input, Commands.EXIT)) { break; }
            else {
                System.out.println("Invalid command!");
            }
        }
    }
}
